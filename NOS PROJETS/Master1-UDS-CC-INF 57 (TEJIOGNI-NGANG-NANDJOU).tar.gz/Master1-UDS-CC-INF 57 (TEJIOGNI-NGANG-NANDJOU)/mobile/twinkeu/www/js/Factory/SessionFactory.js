twinkeu.factory('Autentification',function($http){

	var factory = {
				user : {},
				getNom : function(){
					return factory.user.nom;
				},
				getPrenom : function(){
					return factory.user.prenom;
				},
				getLogin : function(){
					return factory.user.login;
				},
				getPasswd : function(){
					return factory.user.passwd;
				},
				getID : function(){
					return factory.user.id;
				},
				init : function(login,passwd){
					 return $http.get("http://"+GLOBALS.server+":"+GLOBALS.port+"/twinkeu/mobileServlet?action=connexion&&login="+login+"&&passwd="+passwd);
				},
				initActu : function(){
					 return $http.get("http://"+GLOBALS.server+":"+GLOBALS.port+"/twinkeu/mobileServlet?action=listeActu");
				},
				initNote : function(matricule){
					 return $http.get("http://"+GLOBALS.server+":"+GLOBALS.port+"/twinkeu/mobileServlet?action=note&&mat="+matricule);
				},
	};

	return factory;
});