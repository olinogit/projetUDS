twinkeu.controller('NoteCtrl',function($scope){
	$scope.allnotes=GLOBALS.notes.data;
});