var GLOBALS = {
	user : {},
	actu : {},
	notes : {},
	date : {},
	load : true,
	server : '10.42.0.50',
	port : '8080'
};




