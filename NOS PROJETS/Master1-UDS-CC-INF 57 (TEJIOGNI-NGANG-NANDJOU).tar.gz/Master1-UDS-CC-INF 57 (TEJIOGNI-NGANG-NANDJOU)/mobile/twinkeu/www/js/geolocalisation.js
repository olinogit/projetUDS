
/*
	Script pour la Geolocalisation
*/

$(document).ready(function() {

	$("#position .valider").click(function () {
		var lat= $("#position #latitude").val();
		var lon= $("#position #longitude").val();
		
		if((lat != 0) && (lon != 0)) {
			
			$("#position .valider").trigger("click");
		}
	});

});