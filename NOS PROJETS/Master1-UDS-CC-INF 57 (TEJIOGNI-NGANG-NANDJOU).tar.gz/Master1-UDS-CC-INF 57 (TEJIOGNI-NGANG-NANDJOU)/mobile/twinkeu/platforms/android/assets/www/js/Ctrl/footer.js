twinkeu.controller('footerCtrl',function($scope){
	$scope.where='home';
});