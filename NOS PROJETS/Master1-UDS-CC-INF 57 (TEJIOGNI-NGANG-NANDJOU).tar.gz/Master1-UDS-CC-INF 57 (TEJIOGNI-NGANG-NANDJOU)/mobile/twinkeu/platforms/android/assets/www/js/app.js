var twinkeu = angular.module('Twinkeu',['ngRoute']);
	

	// configuration des routes de l application
	twinkeu.config(['$routeProvider',
		  function($routeProvider) {
			    $routeProvider.
			      when('/', {
			        templateUrl: 'pages/connexion.html',
			      }).
			      when('/connexion', {
			        templateUrl: 'pages/connexion.html',
			      }).
			      when('/home', {
			        templateUrl: 'pages/home.html',
			      }).
			      when('/notes', {
			        templateUrl: 'pages/notes.html',
			      }).
			      when('/temp', {
			        templateUrl: 'pages/temp.html',
			      }).
			      when('/alerts', {
			        templateUrl: 'pages/alerts.html',
			      }).
			      when('/modifier', {
			        templateUrl: 'pages/modifier.html',
			      }).
			      when('/localiser', {
			        templateUrl: 'pages/localiser.html',
			      }).
			      when('/contacter', {
			        templateUrl: 'pages/contacter.html',
			      }).
			      when('/deconnexion', {
			        templateUrl: 'pages/deconnexion.html',
			      }).
			      when('/inscription', {
			        templateUrl: 'pages/inscription.html',
			      })
  		}]);




	

	