twinkeu.controller('modifierCtrl',function($scope){
		$('#nom').val(GLOBALS.user.data.nom);
		$('#prenom').val(GLOBALS.user.data.prenom);
		$('#datenaiss').val(GLOBALS.user.data.date);
		$('#lieunaiss').val(GLOBALS.user.data.lieu);
		$('#cni').val(GLOBALS.user.data.cni);
		$('#login').val(GLOBALS.user.data.login);
		$('#pass').val(GLOBALS.user.data.passwd);
		$('#pays').val(GLOBALS.user.data.pays);
		$('#ville').val(GLOBALS.user.data.ville);
		$('#quartier').val(GLOBALS.user.data.quartier);
		$('#telephone').val(GLOBALS.user.data.tel);
		$('#boitemail').val(GLOBALS.user.data.mail);

	});