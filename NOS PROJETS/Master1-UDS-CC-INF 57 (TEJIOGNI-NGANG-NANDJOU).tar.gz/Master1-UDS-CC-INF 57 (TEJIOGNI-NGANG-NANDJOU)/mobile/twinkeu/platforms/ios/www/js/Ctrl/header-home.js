twinkeu.controller('headerHomeCtrl',function($scope){
		$scope.loader = GLOBALS.load;
		$scope.deconexionAction = function(){
			window.location='';
		}
	});