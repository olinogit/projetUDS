twinkeu.controller('connexionCtrl',function($scope,$http,Autentification){
		$scope.formAction = function(){
			$('body').append('<div class="loader"><img src="img/load.gif"></div>');
			Autentification.init($scope.login,$scope.passwd).then(
				function(data){
					console.log(data.data);

					if(data.data!= null ){
						if(data.data.passwd){
							GLOBALS.user=data;


							Autentification.initNote(GLOBALS.user.data.matricule).then(
								function(data){
									console.log(data.data);

									if(data.data!= null ){
											GLOBALS.notes=data;
									}
										
								},
								function(data){
									$('.loader').remove();
									console.log('error du chargemt des notes ');
								});



							Autentification.initActu().then(
								function(data){
									console.log(data.data);

									if(GLOBALS.user.data != null){
										GLOBALS.actu=data;
									    $('.loader').remove();
										window.location='#/home';	
									}
										
								},
								function(data){
									$('.loader').remove();
									console.log('error du chargemt des actus ');
								});


						}

					}
						
				},
				function(data){
					console.log('error'+data);
					$('.loader').remove();
				});


			$('.loader').remove();
		};
	});
