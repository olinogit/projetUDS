

﻿--***************** Création des administrateurs *******************

insert into "administrateur" (login, password)
values ('admin', 'admin');

insert into "administrateur" (login, password)
values ('twinkeu', 'twinkeu');

--***************** insertion d'une actualité *******************
insert into actualite(id_actualite, contenu, titre, id_admin_fk) values ('1','Attaque contre TV5 monde','Cyberattaque','admin');




﻿--************************ Création des cités *************************

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('123', 'Belle cité', 'Delta', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('148', 'Belle cité', 'Cite de la paix', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('147', 'Belle cité', 'Cite de la paix', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('159', 'Belle cité', 'Pilote', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('258', 'Belle cité', 'La sicile', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('321', 'Belle cité', 'Tom and Jerry', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('357', 'Belle cité', 'Le fleuron des internautes', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('369', 'Belle cité', 'Casanostra', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('456', 'Belle cité', 'Fossong', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('654', 'Belle cité', 'Noblesse', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('789', 'Belle cité', 'Cite de la Reussite', 'Cameroun', 'TRUE', 'Dschang');

insert into "cite" (code_cite, description, nom, pays, statut, ville)
values ('987', 'Belle cité', 'El porompompero', 'Cameroun', 'TRUE', 'Dschang');








﻿--*********************** Création des étudiants ************************

insert into "etudiant" (matricule, description, cni, date_naissance, etat, filiere, lieu_naissance, login, mail, niveau, nom, password, pays, prenom, quartier, sexe, statut, telephone, ville, code_cite_fk)
values ('Matricule', 'Petite description', '111111111', '11/11/1999', 'TRUE', 'Mathematiques-Informatique', 'Douala', 'user', 'email', 'Niveau 4', 'NOM', 'user', 'Cameroun', 'Prenom', 'Quartier', 'MASCULIN', 'TRUE', '693909121', 'Dschang', '123');

insert into "etudiant" (matricule, description, cni, date_naissance, etat, filiere, lieu_naissance, login, mail, niveau, nom, password, pays, prenom, quartier, sexe, statut, telephone, ville, code_cite_fk)
values ('Matricule1', 'Petite description', '111139319', '26/07/1992', 'TRUE', 'Mathematiques-Informatique', 'Douala', 'user1', 'mtejiogni@yahoo.fr', 'Niveau 4', 'TEJIOGNI', 'user1', 'Cameroun', 'Marc', 'FOTO', 'MASCULIN', 'TRUE', '693909121', 'Dschang', '123');

insert into "etudiant" (matricule, description, cni, date_naissance, etat, filiere, lieu_naissance, login, mail, niveau, nom, password, pays, prenom, quartier, sexe, statut, telephone, ville, code_cite_fk)
values ('Matricule2', 'Petite description', '111139319', '26/07/1992', 'TRUE', 'Mathematiques-Informatique', 'Douala', 'user2', 'mtejiogni@yahoo.fr', 'Niveau 4', 'TEJIOGNI', 'user2', 'Cameroun', 'Marc', 'FOTO', 'MASCULIN', 'TRUE', '693909121', 'Dschang', '123');

insert into "etudiant" (matricule, description, cni, date_naissance, etat, filiere, lieu_naissance, login, mail, niveau, nom, password, pays, prenom, quartier, sexe, statut, telephone, ville, code_cite_fk)
values ('Matricule3', 'Petite description', '111139319', '26/07/1992', 'TRUE', 'Mathematiques-Informatique', 'Douala', 'user3', 'mtejiogni@yahoo.fr', 'Niveau 4', 'TEJIOGNI', 'user3', 'Cameroun', 'Marc', 'FOTO', 'MASCULIN', 'TRUE', '693909121', 'Dschang', '123');

insert into "etudiant" (matricule, description, cni, date_naissance, etat, filiere, lieu_naissance, login, mail, niveau, nom, password, pays, prenom, quartier, sexe, statut, telephone, ville, code_cite_fk)
values ('Matricule4', 'Petite description', '111139319', '26/07/1992', 'TRUE', 'Mathematiques-Informatique', 'Douala', 'user4', 'mtejiogni@yahoo.fr', 'Niveau 4', 'TEJIOGNI', 'user4', 'Cameroun', 'Marc', 'FOTO', 'MASCULIN', 'TRUE', '693909121', 'Dschang', '123');












