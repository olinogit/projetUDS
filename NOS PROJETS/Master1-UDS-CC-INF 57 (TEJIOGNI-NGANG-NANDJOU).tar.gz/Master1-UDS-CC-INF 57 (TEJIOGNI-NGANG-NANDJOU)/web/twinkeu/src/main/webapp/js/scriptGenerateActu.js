
/*
	Script pour generer des actualit�s
*/

$(document).ready(function() {

	/************************Declarations des variables**********************/
	var generate= 0
	
	
	$("article .boutonPlus").click(function() {
		$("article .plusActu .newActuTest").css("display", "block");
	});
	
});