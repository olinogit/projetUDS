
/*
	Script pour la gestion des notes
*/

$(document).ready(function() {



	/**********************************Imprimer Etudiant*********************************/
	$(".consulterNote_Etudiant .titre .titre2 .imprimer").click(function () {
		
		$(".consulterNote_Etudiant table").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerNote .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Notes</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });

	});














	
	
	
	
	


	/************************************Imprimer************************************/
	$(".selectionnerNote .header .header2 a:first-child img").click(function () {
		$(".selectionnerNote .corps .effacer").css("display", "none");
		
		$(".selectionnerNote .corps").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerNote .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Notes</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
		
		$(".selectionnerNote .corps .effacer").css("display", "block");
	});




















	/****************************Ajouter**************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	pagination(5, ".consulterNote table .corps", ".consulterNote .pagination", 3);
	
	$(".consulterNote table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".consulterNote .selectionnerNote .header").css("display", "block");
		
			$(".consulterNote .selectionnerNote .corps").prepend(
				"<div class='note note"+$position+"'>"+
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Note numero : </span><span class='numero'>"+$("table tr:eq("+$position+") td:eq(0)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Filiere : </span><span>"+$("table tr:eq("+$position+") td:eq(1)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Niveau : </span><span>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Matricule : </span><span>"+$("table tr:eq("+$position+") td:eq(3)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Code du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(4)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Intitule du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(5)").text()+"</span>"+
					"</div>"+
					
					
					
					"<div>"+
						"<span class='mot_important'>Note CC : </span><span>12 / 20</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Note Normal : </span><span>12 / 20</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Note Final : </span><span>12 / 20</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Note Rattrapage : </span><span>12 / 20</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Decision : </span><span>Valider</span>"+
					"</div>"+
					
					
					
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".consulterNote .selectionnerNote .corps .note" + $position).remove();
			
			if($(".consulterNote .selectionnerNote .corps .note").length <= 0) {
				$(".consulterNote table tr").removeClass("fond_orange");
				$(".consulterNote .selectionnerNote .header").css("display", "none");
			}
		}
		
		
		
		$(".consulterNote .selectionnerNote .corps .note .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".consulterNote table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".consulterNote .selectionnerNote .corps .note").length <= 0) {
				$(".consulterNote table tr").removeClass("fond_orange");
				$(".consulterNote .selectionnerNote .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".consulterNote .selectionnerNote .header .header1 span").click(function () {
		$(".consulterNote .selectionnerNote .corps").empty();
		$(".consulterNote table tr").removeClass("fond_orange");
		$(".consulterNote .selectionnerNote .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************************************Modifier*********************************/
	pagination(5, ".modifierNote table .corps", ".modifierNote .pagination", 3);
	
	$(".modifierNote table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".modifierNote .selectionnerNote .header").css("display", "block");
		
			$(".modifierNote .selectionnerNote .corps").prepend(
				"<div class='note note"+$position+"'>"+
					"<div class='bordure'>"+
						">>--------------- Note numero <span class='numero'>"+$position+"</span> ---------------<<"+
					"</div>"+
					
					"<form method='post' action='#'>"+
						"<fieldset>"+
							"<legend>Filiere et Niveau</legend>"+
					
							"<select name='fil'>"+
								"<optgroup label='Faculte des sciences'>"+
									"<option value='fil1'>Mathematiques-Informatique</option>"+
									"<option value='fil2'>Biochimie</option>"+
									"<option value='fil3'>Biologie animale</option>"+
									"<option value='fil4'>Biologie vegetale</option>"+
									"<option value='fil5'>Mathematiques-Informatique</option>"+
									"<option value='fil6'>Chimie</option>"+
									"<option value='fil7'>Physique</option>"+
								"</optgroup>"+
								"<optgroup label='Faculte des lettres'>"+
									"<option value='fil8'>Trilingue </option>"+
									"<option value='fil9'>Biochimie</option>"+
									"<option value='fil10'>Biologie animale</option>"+
									"<option value='fil11'>Biologie v�g�tale</option>"+
								"</optgroup>"+
							"</select>"+
						
							"<select name='niv'>"+
								"<option value='niv1'>Niveau 1</option>"+
								"<option value='niv2'>Niveau 2</option>"+
								"<option value='niv3'>Niveau 3</option>"+
								"<option value='niv4'>Niveau 4</option>"+
								"<option value='niv5'>Niveau 5</option>"+
								"<option value='niv6'>Cycle doctorat</option>"+
							"</select>"+
						
						"</fieldset>"+
						
						
						"<fieldset>"+
							"<legend>Matricule</legend>"+
					
							"<select name='mat'>"+
								"<option value='mat1'>Matricule 1</option>"+
								"<option value='mat2'>Matricule 2</option>"+
								"<option value='mat3'>Matricule 3</option>"+
								"<option value='mat4'>Matricule 4</option>"+
								"<option value='mat5'>Matricule 5</option>"+
								"<option value='mat6'>Matricule 6</option>"+
								"<option value='mat7'>Matricule 7</option>"+
								"<option value='mat8'>Matricule 8</option>"+
								"<option value='mat9'>Matricule 9</option>"+
								"<option value='mat10'>Matricule 10</option>"+
							"</select>"+
						
						"</fieldset>"+
						
						
					
						"<fieldset>"+
							"<legend>Code et Intitule du cours</legend>"+
					
							"<input type='text' name='code' id='code' value='"+$("table tr:eq("+$position+") td:eq(4)").text()+"' placeholder='Code du cours' />"+
							"<input type='text' name='intitule' id='intitule' value='"+$("table tr:eq("+$position+") td:eq(5)").text()+"' placeholder='intitule du cours' />"+
						"</fieldset>"+
				
				
				
				
				
						
						"<br />"+
						"<fieldset>"+
							"<legend>Note (Controle continu)</legend>"+
				
							"<input type='text' name='noteCC' id='noteCC' value='' placeholder='/20' />"+
						"</fieldset>"+
					
						"<br />"+
						"<fieldset>"+
							"<legend>Notes (Session normale)</legend>"+
				
							"<input type='text' name='noteNormale' id='noteNormale' value='' placeholder='/20' />"+
							"<input type='text' name='noteFinale' id='noteFinale' value='' placeholder='/20' />"+
						"</fieldset>"+
					
						"<br />"+
						"<fieldset>"+
							"<legend>Note (Session de ratrappage)</legend>"+
				
							"<input type='text' name='noteRattrapage' id='noteRattrapge' value='' placeholder='/20' />"+
						"</fieldset>"+
					
						"<br />"+
						"<fieldset>"+
							"<legend>Decision</legend>"+
					
							"<input type='radio' name='decision' id='v' value='valider' checked />"+
							"<label for='v'>Valider</label>"+
					
							"<br />"+
							"<input type='radio' name='decision' id='nv' value='non_valider' />"+
							"<label for='nv'>Non Valider</label>"+
						"</fieldset>"+
						
				
				
				
						"<br />"+
						"<input type='reset' name='effacer' class='reinitialiser' value='Reinitialiser' />"+
						"<input type='submit' name='modifier' class='modifier' value='Modifier' />"+
					"</form>"+
					"<div class='bordure'>"+
						">>----------------------------------------------------------------------------------------<<"+
					"</div>"+
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".modifierNote .selectionnerNote .corps .note" + $position).remove();
			
			if($(".modifierNote .selectionnerNote .corps .note").length <= 0) {
				$(".modifierNote table tr").removeClass("fond_orange");
				$(".modifierNote .selectionnerNote .header").css("display", "none");
			}
		}
		
		
		//--------------> Evenement sur le bouton modifier
		$(".modifierNote .selectionnerNote .corps .note .modifier").click(function (e) {
			//e.preventDefault();
			//$(".modifierEmploi table").load($(this).attr('href'));
		});
		
		
		
		
		$(".modifierNote .selectionnerNote .corps .note .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".modifierNote table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".modifierNote .selectionnerNote .corps .note").length <= 0) {
				$(".modifierNote table tr").removeClass("fond_orange");
				$(".modifierNote .selectionnerNote .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".modifierNote .selectionnerNote .header .header1 span").click(function () {
		$(".modifierNote .selectionnerNote .corps").empty();
		$(".modifierNote table tr").removeClass("fond_orange");
		$(".modifierNote .selectionnerNote .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/********************************************Supprimer*******************************/
	pagination(5, ".supprimerNote table .corps", ".supprimerNote .pagination", 3);
	
	$(".supprimerNote table tr").click(function () {
		$(this).toggleClass("fond_orange");
	});
	
	$(".supprimerNote .selectionnerNote .boutonSupprimer span").click(function () {
		taille= $(".supprimerNote table tr").length;
		
		for(i= 0; i<taille; i++) {
			if ($(".supprimerNote table tr:eq("+i+")").hasClass("fond_orange")) {
				$(".supprimerNote table tr:eq("+i+")").remove();
			}
		}
		
	});
	
	
});