
/*
	Script pour la gestion du profil d'une personne
*/

$(document).ready(function() {
	
	/**********************************Imprimer*********************************/
	$(".consulterProfil .titre .titre2 a:first-child img").click(function () {
		
		$(".consulterProfil .infos").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : "",
            //Add this at top
            prepend : "",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
	});
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	
	
	
	
	/*****************************Modifier************************/
	
});