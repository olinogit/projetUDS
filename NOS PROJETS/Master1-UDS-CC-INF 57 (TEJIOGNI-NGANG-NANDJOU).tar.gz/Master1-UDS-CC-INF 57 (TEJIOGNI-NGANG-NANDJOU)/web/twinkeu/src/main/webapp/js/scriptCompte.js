
/*
	Script pour la gestion d'un compte
*/

$(document).ready(function() {

	/**********************************Imprimer*********************************/
	$(".selectionnerCompte .header .header2 a:first-child img").click(function () {
		$(".selectionnerCompte .corps .effacer").css("display", "none");
		
		$(".selectionnerCompte .corps").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerCompte .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Comptes</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
		
		$(".selectionnerCompte .corps .effacer").css("display", "block");
	});























	/****************************Ajouter**************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	pagination(5, ".consulterCompte table .corps", ".consulterCompte .pagination", 3);
	
	$(".consulterCompte table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".consulterCompte .selectionnerCompte .header").css("display", "block");
		
			$(".consulterCompte .selectionnerCompte .corps").prepend(
				"<div class='compte compte"+$position+"'>"+
				
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					"<div>"+
						"<span class='mot_important'>Compte numero : </span><span class='numero'>"+$("table tr:eq("+$position+") td:eq(0)").text()+"</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Nom : </span><span>"+$("table tr:eq("+$position+") td:eq(1)").text()+"</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Prenom : </span><span>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Sexe : </span><span>M</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Date de naissance : </span><span>26/07/1992</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Lieu de naissance : </span><span>DOUALA</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Numero de CNI : </span><span>111139319</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Login : </span><span>Voisin</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Password : </span><span>abcd123</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Pays : </span><span>"+$("table tr:eq("+$position+") td:eq(3)").text()+"</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Ville : </span><span>Dschang</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Quartier : </span><span>FOTO</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Telephone : </span><span>"+$("table tr:eq("+$position+") td:eq(4)").text()+"</span>"+
					"</div>"+
					
					"<div>"+
						"<span class='mot_important'>Email : </span><span>"+$("table tr:eq("+$position+") td:eq(5)").text()+"</span>"+
					"</div>"+
					
					
					
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
					
				"</div>"
			);
		}
		else {
			$(".consulterCompte .selectionnerCompte .corps .compte" + $position).remove();
			
			if($(".consulterCompte .selectionnerCompte .corps .compte").length <= 0) {
				$(".consulterCompte table tr").removeClass("fond_orange");
				$(".consulterCompte .selectionnerCompte .header").css("display", "none");
			}
		}
		
		
		
		$(".consulterCompte .selectionnerCompte .corps .compte .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".consulterCompte table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".consulterCompte .selectionnerCompte .corps .compte").length <= 0) {
				$(".consulterCompte table tr").removeClass("fond_orange");
				$(".consulterCompte .selectionnerCompte .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".consulterCompte .selectionnerCompte .header .header1 span").click(function () {
		$(".consulterCompte .selectionnerCompte .corps").empty();
		$(".consulterCompte table tr").removeClass("fond_orange");
		$(".consulterCompte .selectionnerCompte .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************************************Modifier*********************************/
	pagination(5, ".modifierCompte table .corps", ".modifierCompte .pagination", 3);
	
	$(".modifierCompte table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".modifierCompte .selectionnerCompte .header").css("display", "block");
		
			$(".modifierCompte .selectionnerCompte .corps").prepend(
				"<div class='compte compte"+$position+"'>"+
				
					"<div class='bordure'>"+
						">>--------------- Compte numero <span class='numero'>"+$position+"</span> ---------------<<"+
					"</div>"+
					
					
					"<form method='post' action='#'>"+
					
						"<fieldset>"+
							"<legend>Modifier votre photo de profil</legend>"+
					
							"<img src='img/user-default-2-large.png' alt='image' width='30%' />"+
				
							"<br />"+
							"<input type='file' name='image' id='image' />"+
						"</fieldset>"+
						
						
						"<fieldset>"+
							"<legend>Nom et prenom</legend>"+
					
							"<input type='text' name='nom' id='nom' value='"+$("table tr:eq("+$position+") td:eq(1)").text()+"' placeholder='Code du cours' required />"+
							"<input type='text' name='prenom' id='prenom' value='"+$("table tr:eq("+$position+") td:eq(2)").text()+"' placeholder='intitule du cours' required />"+
						"</fieldset>"+
				
				
						"<br />"+
						"<fieldset>"+
							"<legend>Etez-vous un homme ou une femme ?</legend>"+
					
							"<input type='radio' name='sex' id='homme' value='homme' checked />"+
							"<label for='homme'>Homme</label>"+
					
							"<br />"+
							"<input type='radio' name='sex' id='femme' value='femme' />"+
							"<label for='femme'>Femme</label>"+
						"</fieldset>"+
					
					
						"<br />"+
						"<fieldset>"+
							"<legend>Date et lieu de naissance</legend>"+
					
							"<input type='date' name='datenaiss' id='datenaiss' value='' placeholder='Date de naissance' />"+
							"<label for='place'>a</label>"+
							"<input type='text' name='lieunaiss' id='lieunaiss' value='' placeholder='Lieu de naissance' />"+
						"</fieldset>"+
						
						
						"<br />"+
						"<fieldset>"+
							"<legend>Num�ro de CNI</legend>"+
					
							"<input type='text' name='cni' id='cni' value='' placeholder='xxxxxxxxxx' />"+
						"</fieldset>"+
				
				
						"<br />"+
						"<fieldset>"+
							"<legend>Login et mot de passe de votre compte</legend>"+
					
							"<input type='text' name='login' id='login' placeholder='Login' />"+
							"<input type='password' name='pass' id='pass' placeholder='Mot de passe' />"+
						"</fieldset>"+
						
						
						"<br />"+
						"<fieldset>"+
							"<legend>Informations supplementaires</legend>"+
					
							"<label for='pays'>Pays</label>"+
							"<input type='text' name='pays' id='pays' value='"+$("table tr:eq("+$position+") td:eq(3)").text()+"' placeholder='Ex : Cameroon' />"+
				
							"<br /><br />"+
							"<label for='ville'>Ville</label>"+
							"<input type='text' name='ville' id='ville' value='' placeholder='Ex : Dschang' />"+
				
							"<br /><br />"+
							"<label for='quartier'>Quartier</label>"+
							"<input type='text' name='quartier' id='quartier' value='' placeholder='Ex : Tin cup' />"+
				
							"<br /><br />"+
							"<label for='telephone'>Telephone</label>"+
							"<input type='tel' name='telephone' id='telephone' value='"+$("table tr:eq("+$position+") td:eq(4)").text()+"' placeholder='Ex : +237 693909121' />"+
				
							"<br /><br />"+
							"<label for='boitemail'>Email</label>"+
							"<input type='email' name='boitemail' id='boitemail' value='"+$("table tr:eq("+$position+") td:eq(5)").text()+"' placeholder='Ex : example@yahoo.fr' />"+
						"</fieldset>"+
						
						
						"<br />"+
						"<input type='reset' name='effacer' class='reinitialiser' value='Reinitialiser' />"+
						"<input type='submit' name='modifier' class='modifier' value='Modifier' />"+
						
					"</form>"+
					
					
					
					"<div class='bordure'>"+
						">>----------------------------------------------------------------------------------------<<"+
					"</div>"+
					
					
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".modifierCompte .selectionnerCompte .corps .compte" + $position).remove();
			
			if($(".modifierCompte .selectionnerCompte .corps .compte").length <= 0) {
				$(".modifierCompte table tr").removeClass("fond_orange");
				$(".modifierCompte .selectionnerCompte .header").css("display", "none");
			}
		}
		
		
		//--------------> Evenement sur le bouton modifier
		$(".modifierCompte .selectionnerCompte .corps .compte .modifier").click(function (e) {
			//e.preventDefault();
			//$(".modifierEmploi table").load($(this).attr('href'));
		});
		
		
		
		
		$(".modifierCompte .selectionnerCompte .corps .compte .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".modifierCompte table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".modifierCompte .selectionnerCompte .corps .compte").length <= 0) {
				$(".modifierCompte table tr").removeClass("fond_orange");
				$(".modifierCompte .selectionnerCompte .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".modifierCompte .selectionnerCompte .header .header1 span").click(function () {
		$(".modifierCompte .selectionnerCompte .corps").empty();
		$(".modifierCompte table tr").removeClass("fond_orange");
		$(".modifierCompte .selectionnerCompte .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/********************************************Supprimer*******************************/
	pagination(5, ".supprimerCompte table .corps", ".supprimerCompte .pagination", 3);
	
	$(".supprimerCompte table tr").click(function () {
		$(this).toggleClass("fond_orange");
	});
	
	$(".supprimerCompte .selectionnerCompte .boutonSupprimer span").click(function () {
		taille= $(".supprimerCompte table tr").length;
		
		for(i= 0; i<taille; i++) {
			if ($(".supprimerCompte table tr:eq("+i+")").hasClass("fond_orange")) {
				$(".supprimerCompte table tr:eq("+i+")").remove();
			}
		}
		
	});
	
	
});