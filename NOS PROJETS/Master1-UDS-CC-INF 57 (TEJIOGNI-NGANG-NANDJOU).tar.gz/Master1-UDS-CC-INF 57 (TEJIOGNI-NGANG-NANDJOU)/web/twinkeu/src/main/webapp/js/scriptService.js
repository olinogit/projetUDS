
/*
	Script la gestion l'onglet Services
*/

$(document).ready(function() {
	
	/**********************************Imprimer*********************************/
	$(".corps .telecharger .imprimer").click(function () {
		
		$(".corps .divImprimer").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : "",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Sercives</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
	});
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************************Telecharger**************************/
	
	
	
	
	
	
	
	
	
	
	
});