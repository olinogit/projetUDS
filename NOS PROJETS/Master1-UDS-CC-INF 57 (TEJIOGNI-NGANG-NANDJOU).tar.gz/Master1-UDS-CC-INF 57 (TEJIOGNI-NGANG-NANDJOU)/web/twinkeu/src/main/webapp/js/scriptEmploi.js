
/*
	Script pour la gestion de l'emploi du temps
*/

$(document).ready(function() {

	/**********************************Imprimer Etudiant*********************************/
	$(".consulterEmploi_Etudiant .titre .titre2 .imprimer img").click(function () {
		
		$(".consulterEmploi_Etudiant table").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerEmploi .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Emploi du temps</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
	});














	/**********************************Imprimer*********************************/
	$(".selectionnerEmploi .header .header2 a:first-child img").click(function () {
		$(".selectionnerEmploi .corps .effacer").css("display", "none");
		
		$(".selectionnerEmploi .corps").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerEmploi .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Emploi du temps</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
		
		$(".selectionnerEmploi .corps .effacer").css("display", "block");
	});


















	/****************************Ajouter**************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	pagination(5, ".consulterEmploi table .corps", ".consulterEmploi .pagination", 3);
	
	$(".consulterEmploi table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".consulterEmploi .selectionnerEmploi .header").css("display", "block");
		
			$(".consulterEmploi .selectionnerEmploi .corps").prepend(
				"<div class='emploi emploi"+$position+"'>"+
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Emploi de temps numero : </span><span class='numero'>"+$("table tr:eq("+$position+") td:eq(0)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Filiere : </span><span>"+$("table tr:eq("+$position+") td:eq(1)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Niveau : </span><span>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Code du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(3)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Intitule du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(4)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Date du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(5)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Heure du cours : </span><span>"+$("table tr:eq("+$position+") td:eq(6)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Description : </span><span>"+$("table tr:eq("+$position+") td:eq(7)").text()+"</span>"+
					"</div>"+
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".consulterEmploi .selectionnerEmploi .corps .emploi" + $position).remove();
			
			if($(".consulterEmploi .selectionnerEmploi .corps .emploi").length <= 0) {
				$(".consulterEmploi table tr").removeClass("fond_orange");
				$(".consulterEmploi .selectionnerEmploi .header").css("display", "none");
			}
		}
		
		
		
		$(".consulterEmploi .selectionnerEmploi .corps .emploi .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".consulterEmploi table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".consulterEmploi .selectionnerEmploi .corps .emploi").length <= 0) {
				$(".consulterEmploi table tr").removeClass("fond_orange");
				$(".consulterEmploi .selectionnerEmploi .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".consulterEmploi .selectionnerEmploi .header .header1 span").click(function () {
		$(".consulterEmploi .selectionnerEmploi .corps").empty();
		$(".consulterEmploi table tr").removeClass("fond_orange");
		$(".consulterEmploi .selectionnerEmploi .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************************************Modifier*********************************/
	pagination(5, ".modifierEmploi table .corps", ".modifierEmploi .pagination", 3);
	
	$(".modifierEmploi table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".modifierEmploi .selectionnerEmploi .header").css("display", "block");
		
			$(".modifierEmploi .selectionnerEmploi .corps").prepend(
				"<div class='emploi emploi"+$position+"'>"+
					"<div class='bordure'>"+
						">>--------------- Emploi de temps numero <span class='numero'>"+$position+"</span> ---------------<<"+
					"</div>"+
					"<form method='post' action='#'>"+
						"<fieldset>"+
							"<legend>Filiere et Niveau</legend>"+
					
							"<select name='fil'>"+
								"<optgroup label='Faculte des sciences'>"+
									"<option value='fil1'>Mathematiques-Informatique</option>"+
									"<option value='fil2'>Biochimie</option>"+
									"<option value='fil3'>Biologie animale</option>"+
									"<option value='fil4'>Biologie vegetale</option>"+
									"<option value='fil5'>Mathematiques-Informatique</option>"+
									"<option value='fil6'>Chimie</option>"+
									"<option value='fil7'>Physique</option>"+
								"</optgroup>"+
								"<optgroup label='Faculte des lettres'>"+
									"<option value='fil8'>Trilingue </option>"+
									"<option value='fil9'>Biochimie</option>"+
									"<option value='fil10'>Biologie animale</option>"+
									"<option value='fil11'>Biologie v�g�tale</option>"+
								"</optgroup>"+
							"</select>"+
						
							"<select name='niv'>"+
								"<option value='niv1'>Niveau 1</option>"+
								"<option value='niv2'>Niveau 2</option>"+
								"<option value='niv3'>Niveau 3</option>"+
								"<option value='niv4'>Niveau 4</option>"+
								"<option value='niv5'>Niveau 5</option>"+
								"<option value='niv6'>Cycle doctorat</option>"+
							"</select>"+
						
						"</fieldset>"+
					
						"<fieldset>"+
							"<legend>Code et Intitule du cours</legend>"+
					
							"<input type='text' name='code' id='code' value='"+$("table tr:eq("+$position+") td:eq(3)").text()+"' placeholder='Code du cours' required />"+
							"<input type='text' name='intitule' id='intitule' value='"+$("table tr:eq("+$position+") td:eq(4)").text()+"' placeholder='intitule du cours' required />"+
						"</fieldset>"+
				
				
						"<br />"+
						"<fieldset>"+
							"<legend>Date et Heure</legend>"+
				
							"<input type='date' name='dateEmploi' id='dateEmploi' value='"+$("table tr:eq("+$position+") td:eq(5)").text()+"' placeholder='jj/mm/aa' required />"+
							"<input type='time' name='heureEmploi' id='heureEmploi' value='"+$("table tr:eq("+$position+") td:eq(6)").text()+"' placeholder='hh:mm' required />"+
						"</fieldset>"+
					
					
						"<br />"+
						"<fieldset>"+
							"<legend>Description</legend>"+
					
							"<textarea rows='10' cols='30'>"+$("table tr:eq("+$position+") td:eq(7)").text()+"</textarea>"+
						"</fieldset>"+
				
						"<br />"+
						"<input type='reset' name='effacer' class='reinitialiser' value='Reinitialiser' />"+
						"<input type='submit' name='modifier' class='modifier' value='Modifier' />"+
					"</form>"+
					"<div class='bordure'>"+
						">>----------------------------------------------------------------------------------------<<"+
					"</div>"+
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".modifierEmploi .selectionnerEmploi .corps .emploi" + $position).remove();
			
			if($(".modifierEmploi .selectionnerEmploi .corps .emploi").length <= 0) {
				$(".modifierEmploi table tr").removeClass("fond_orange");
				$(".modifierEmploi .selectionnerEmploi .header").css("display", "none");
			}
		}
		
		
		//--------------> Evenement sur le bouton modifier
		$(".modifierEmploi .selectionnerEmploi .corps .emploi .modifier").click(function (e) {
			//e.preventDefault();
			//$(".modifierEmploi table").load($(this).attr('href'));
		});
		
		
		
		
		$(".modifierEmploi .selectionnerEmploi .corps .emploi .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".modifierEmploi table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".modifierEmploi .selectionnerEmploi .corps .emploi").length <= 0) {
				$(".modifierEmploi table tr").removeClass("fond_orange");
				$(".modifierEmploi .selectionnerEmploi .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".modifierEmploi .selectionnerEmploi .header .header1 span").click(function () {
		$(".modifierEmploi .selectionnerEmploi .corps").empty();
		$(".modifierEmploi table tr").removeClass("fond_orange");
		$(".modifierEmploi .selectionnerEmploi .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/********************************************Supprimer*******************************/
	pagination(5, ".supprimerEmploi table .corps", ".supprimerEmploi .pagination", 3);
	
	$(".supprimerEmploi table tr").click(function () {
		$(this).toggleClass("fond_orange");
	});
	
	$(".supprimerEmploi .selectionnerEmploi .boutonSupprimer span").click(function () {
		taille= $(".supprimerEmploi table tr").length;
		
		for(i= 0; i<taille; i++) {
			if ($(".supprimerEmploi table tr:eq("+i+")").hasClass("fond_orange")) {
				$(".supprimerEmploi table tr:eq("+i+")").remove();
			}
		}
		
	});
	
	
});