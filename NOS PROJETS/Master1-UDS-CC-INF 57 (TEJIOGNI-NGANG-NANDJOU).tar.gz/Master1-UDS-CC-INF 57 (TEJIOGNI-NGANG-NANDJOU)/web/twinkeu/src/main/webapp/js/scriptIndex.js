

$(document).ready(function() {
	
	var affiche= 0;
	
	$("header .header2 form span").click(function(){
		$("section .publicite img").toggle("show");
		
		if (affiche == 0) {
			$("section .formulaire").css("display", "inline-block");
			affiche= 1;
		}
		else {
			$("section .formulaire").css("display", "none");
			affiche= 0;
		}
		
	});
	
});