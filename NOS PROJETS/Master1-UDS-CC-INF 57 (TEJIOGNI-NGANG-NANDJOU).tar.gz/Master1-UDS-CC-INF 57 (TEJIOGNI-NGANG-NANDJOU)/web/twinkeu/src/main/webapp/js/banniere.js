/* Banniere */

$(document).ready(function() {

	// Empilage des differentes photos
	$(".banniere_photo img:gt(0)").hide();
	
	// Gestionnaire de clic sur le lien suivant
	$("#banniere .banniere_outils:last-child").click(function() {
		var $image_suivante = $(".banniere_photo img:visible").next("img");
		if($image_suivante.length<1) $image_suivante = $(".banniere_photo img:first");
		$(".banniere_photo img:visible").fadeOut();
		$image_suivante.fadeIn();
		return false;
	});

	// Gestionnaire de clic sur le lien précédent
	$("#banniere .banniere_outils:first-child").click(function() {
		var $image_precedente = $(".banniere_photo img:visible").prev("img");
		if($image_precedente.length<1) $image_precedente = $(".banniere_photo img:last");
		$(".banniere_photo img:visible").fadeOut();
		$image_precedente.fadeIn();
		return false;
	});
	
	// Défilement automatique
	function auto() {
		// On déclenche volontairement l'événement "click" sur le lien suivant
		$("#banniere .banniere_outils:last-child").trigger("click");
	}
	
	// La fonction setInterval nous permet de déclencher la fonction "auto" toutes les 2000 ms
	setInterval(auto, 8000);
	
});
