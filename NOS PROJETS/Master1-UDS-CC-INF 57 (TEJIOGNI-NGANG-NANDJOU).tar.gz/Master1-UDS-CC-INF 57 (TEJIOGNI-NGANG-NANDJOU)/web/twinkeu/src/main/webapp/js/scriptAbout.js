
/*
	Script la gestion l'onglet About
*/

$(document).ready(function() {
	
	/**********************************Imprimer*********************************/
	$(".corps .telecharger .imprimer").click(function () {
		
		$(".corps .divImprimer").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : "",
            //Add this at top
            prepend : "",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
	});
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************************Telecharger**************************/
	$(".corps .telecharger .pdf").click(function () {
		
		htmlFromPdf($(".corps .divImprimer").html(), 20, 20, 500, "About.pdf");
		
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*Convertir du code HTML en PDF*/
	function htmlFromPdf(sourceHTML, top, left, width, filePDF) {
		
		var doc= new jsPDF('p', 'pt', 'letter');

		var specialElementHandlers= {
			'#bypassme': function(element, renderer) {
				return true;
			}
		};

		doc.fromHTML(
				sourceHTML,
				top,
				left,
				{
					'width': width,
					'elementHandlers': specialElementHandlers
				},

				function(dispose) {
					doc.save(filePDF);
				}
			);
	}
	
	
	
	
});