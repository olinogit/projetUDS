
/*
	Script pour la gestion de l'actualit�
*/

$(document).ready(function() {
	
	/**********************************Imprimer*********************************/
	$(".selectionnerActu .header .header2 a:first-child img").click(function () {
		$(".selectionnerActu .corps .effacer").css("display", "none");
		
		$(".selectionnerActu .corps").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerActu .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Actualites</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
		
		$(".selectionnerActu .corps .effacer").css("display", "block");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Ajouter**************************/
	
	
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	pagination(5, ".consulterActu table .corps", ".consulterActu .pagination", 3);
	
	$(".consulterActu table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".consulterActu .selectionnerActu .header").css("display", "block");
		
			$(".consulterActu .selectionnerActu .corps").prepend(
				"<div class='actu actu"+$position+"'>"+
				
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					"<div>"+
						"<span class='mot_important'>Actualite numero : </span><span class='numero'>"+$("table tr:eq("+$position+") td:eq(0)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Titre : </span><span>"+$("table tr:eq("+$position+") td:eq(1)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Description : </span><span>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</span>"+
					"</div>"+
					
					
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".consulterActu .selectionnerActu .corps .actu" + $position).remove();
			
			if($(".consulterActu .selectionnerActu .corps .actu").length <= 0) {
				$(".consulterActu table tr").removeClass("fond_orange");
				$(".consulterActu .selectionnerActu .header").css("display", "none");
			}
		}
		
		
		
		$(".consulterActu .selectionnerActu .corps .actu .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".consulterActu table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".consulterActu .selectionnerActu .corps .actu").length <= 0) {
				$(".consulterActu table tr").removeClass("fond_orange");
				$(".consulterActu .selectionnerActu .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".consulterActu .selectionnerActu .header .header1 span").click(function () {
		$(".consulterActu .selectionnerActu .corps").empty();
		$(".consulterActu table tr").removeClass("fond_orange");
		$(".consulterActu .selectionnerActu .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************************************Modifier*********************************/
	pagination(5, ".modifierActu table .corps", ".modifierActu .pagination", 3);
	
	$(".modifierActu table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".modifierActu .selectionnerActu .header").css("display", "block");
		
			$(".modifierActu .selectionnerActu .corps").prepend(
				"<div class='actu actu"+$position+"'>"+
				
					"<div class='bordure'>"+
						">>--------------- Actuaite numero <span class='numero'>"+$position+"</span> ---------------<<"+
					"</div>"+
					
					
					"<form method='post' action='#'>"+
					
						"<fieldset>"+
							"<legend>Modifier l'image de votre actualite</legend>"+
						
							"<input type='file' name='image' id='image' />"+
						"</fieldset>"+
						
						
					
						"<fieldset>"+
							"<legend>Modifier le titre</legend>"+
					
							"<input type='text' name='titre' id='titre' value='"+$("table tr:eq("+$position+") td:eq(1)").text()+"' placeholder='Titre' />"+
							
						"</fieldset>"+
				
						
						"<br />"+
						"<fieldset>"+
							"<legend>Modifier le contenu</legend>"+
					
							"<textarea rows='10' cols='30'>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</textarea>"+
						"</fieldset>"+
					
						
						"<br />"+
						"<input type='reset' name='effacer' class='reinitialiser' value='Reinitialiser' />"+
						"<input type='submit' name='modifier' class='modifier' value='Modifier' />"+
					"</form>"+
					
					
					"<div class='bordure'>"+
						">>----------------------------------------------------------------------------------------<<"+
					"</div>"+
					
					
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".modifierActu .selectionnerActu .corps .actu" + $position).remove();
			
			if($(".modifierActu .selectionnerActu .corps .actu").length <= 0) {
				$(".modifierActu table tr").removeClass("fond_orange");
				$(".modifierActu .selectionnerActu .header").css("display", "none");
			}
		}
		
		
		//--------------> Evenement sur le bouton modifier
		$(".modifierActu .selectionnerActu .corps .actu .modifier").click(function (e) {
			//e.preventDefault();
			//$(".modifierEmploi table").load($(this).attr('href'));
		});
		
		
		
		
		$(".modifierActu .selectionnerActu .corps .actu .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".modifierActu table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".modifierActu .selectionnerActu .corps .actu").length <= 0) {
				$(".modifierActu table tr").removeClass("fond_orange");
				$(".modifierActu .selectionnerActu .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".modifierActu .selectionnerActu .header .header1 span").click(function () {
		$(".modifierActu .selectionnerActu .corps").empty();
		$(".modifierActu table tr").removeClass("fond_orange");
		$(".modifierActu .selectionnerActu .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/********************************************Supprimer*******************************/
	pagination(5, ".supprimerActu table .corps", ".supprimerActu .pagination", 3);
	
	$(".supprimerActu table tr").click(function () {
		$(this).toggleClass("fond_orange");
	});
	
	$(".supprimerActu .selectionnerActu .boutonSupprimer span").click(function () {
		taille= $(".supprimerActu table tr").length;
		
		for(i= 0; i<taille; i++) {
			if ($(".supprimerActu table tr:eq("+i+")").hasClass("fond_orange")) {
				$(".supprimerActu table tr:eq("+i+")").remove();
			}
		}
		
	});
	
	
});