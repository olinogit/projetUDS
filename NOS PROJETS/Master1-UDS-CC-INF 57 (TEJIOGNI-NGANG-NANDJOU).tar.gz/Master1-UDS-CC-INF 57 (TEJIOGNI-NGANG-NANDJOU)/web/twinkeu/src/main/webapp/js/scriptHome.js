
/*
	Script la gestion l'onglet Home
*/

$(document).ready(function() {
	
	
	
	
	
	
	
	
	
	
	
	
});