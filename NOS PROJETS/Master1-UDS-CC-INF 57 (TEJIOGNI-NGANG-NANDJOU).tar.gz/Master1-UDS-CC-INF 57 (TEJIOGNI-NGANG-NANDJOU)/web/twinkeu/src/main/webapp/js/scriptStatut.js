
/*
	Script pour la gestion du statut d'une personne
*/

$(document).ready(function() {
	
	/****************************Etudiant**************************/
	
	
	
	
	/*****************************Concierge************************/
	$(".formulaire-concierge form .boutonOK").click(function() {
		nbCite= $(".formulaire-concierge form .nombre").val();
		$(".formulaire-concierge form fieldset .selectionnerCite").empty();
		
		if(nbCite > 0) {
			for(i= 0; i<nbCite; i++) {
				$(".formulaire-concierge form fieldset .selectionnerCite").append(""+
					"<fieldset>"+
						"<legend>Selectionnez la cite "+(i+1)+" et entrez le code correspondant (<span class='mark'>*</span>)</legend>"+
						"<select name='cite'>"+
							"<option value='cite1'>Cite de la reussite</option>"+
							"<option value='cite2'>La sicile</option>"+
							"<option value='cite3'>No name city</option>"+
							"<option value='cite4'>El porompompero</option>"+
							"<option value='cite5'>cite high pere</option>"+
							"<option value='cite6'>Cite poum bat tejio</option>"+
						"</select>"+
						"<br /><br />"+
						"<input type='text' name='code' class='code' placeholder='code' required />"+
					"</fieldset>"
				);
			}
		}
	});
	
	
});