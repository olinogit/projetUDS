
/*
	Script pour la Geolocalisation
*/

$(document).ready(function() {

	$("#position .valider").click(function () {
		
	});
	
	
	
	function auto() {
		var lat= $("#position #latitude").val();
		var lon= $("#position #longitude").val();
		
		if((lat != 0) && (lon != 0)) {
			alert("Alerte de securite \n\n"+
					"************************************\n"+
					"Latitude : "+lat+"\n"+
					"Longitude : "+lon+"\n"+
					"*************************************\n\n"+
					"Ne vous inquietez pas les renforts arrivent \n\n"+
					"Deconnexion"
				);
		
			$("#position .valider").trigger("click");
		}
		
	}
	
	//setInterval(auto, 25000);
	setInterval(auto, 1000);

});