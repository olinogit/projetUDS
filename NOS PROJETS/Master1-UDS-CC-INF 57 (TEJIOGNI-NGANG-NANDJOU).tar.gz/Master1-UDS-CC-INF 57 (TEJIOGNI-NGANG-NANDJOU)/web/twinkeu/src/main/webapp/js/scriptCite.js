
/*
	Script pour la gestion d'une cit�
*/

$(document).ready(function() {
	
	/**********************************Imprimer*********************************/
	$(".selectionnerCite .header .header2 a:first-child img").click(function () {
		$(".selectionnerCite .corps .effacer").css("display", "none");
		
		$(".selectionnerCite .corps").print({
            //Use Global styles
            globalStyles : false,
			//Add link with attrbute media=print
            mediaPrint : false,
            //Custom stylesheet
            stylesheet : "http://fonts.googleapis.com/css?family=Inconsolata",
            //Print in a hidden iframe
            iframe : false,
            //Don't print this
            noPrintSelector : ".selectionnerCite .corps .effacer",
            //Add this at top
            prepend : "<center>"+
						"<img src='img/logo.png' alt='logo' width='30%' title='Le messager' />"+
						"<br /><br />"+
						"<h1>Cites</h1>"+
						"<img src='img/trait.png' width='30%' />"+
						"<br /><br />"+
						"</center>",
            //Add this on bottom
            append : "<br/>Buh Bye!"
        });
		
		
		$(".selectionnerCite .corps .effacer").css("display", "block");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Ajouter**************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	/****************************Consulter**************************/
	pagination(5, ".consulterCite table .corps", ".consulterCite .pagination", 3);
	
	$(".consulterCite table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".consulterCite .selectionnerCite .header").css("display", "block");
		
			$(".consulterCite .selectionnerCite .corps").prepend(
				"<div class='cite cite"+$position+"'>"+
				
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					
					"<div>"+
						"<span class='mot_important'>Cite numero : </span><span class='numero'>"+$("table tr:eq("+$position+") td:eq(0)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Code cite : </span><span>"+$("table tr:eq("+$position+") td:eq(1)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Nom : </span><span>"+$("table tr:eq("+$position+") td:eq(2)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Pays : </span><span>"+$("table tr:eq("+$position+") td:eq(3)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Ville : </span><span>"+$("table tr:eq("+$position+") td:eq(4)").text()+"</span>"+
					"</div>"+
					"<div>"+
						"<span class='mot_important'>Description : </span><span>"+$("table tr:eq("+$position+") td:eq(5)").text()+"</span>"+
					"</div>"+
					
					
					
					
					"<div class='bordure'>"+
						"|--------------------------------------------------------------------------------|"+
					"</div>"+
					
					
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
					
				"</div>"
			);
		}
		else {
			$(".consulterCite .selectionnerCite .corps .cite" + $position).remove();
			
			if($(".consulterCite .selectionnerCite .corps .cite").length <= 0) {
				$(".consulterCite table tr").removeClass("fond_orange");
				$(".consulterCite .selectionnerCite .header").css("display", "none");
			}
		}
		
		
		
		$(".consulterCite .selectionnerCite .corps .cite .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".consulterCite table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".consulterCite .selectionnerCite .corps .cite").length <= 0) {
				$(".consulterCite table tr").removeClass("fond_orange");
				$(".consulterCite .selectionnerCite .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".consulterCite .selectionnerCite .header .header1 span").click(function () {
		$(".consulterCite .selectionnerCite .corps").empty();
		$(".consulterCite table tr").removeClass("fond_orange");
		$(".consulterCite .selectionnerCite .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************************************Modifier*********************************/
	pagination(5, ".modifierCite table .corps", ".modifierCite .pagination", 3);
	
	$(".modifierCite table tr").click(function () {
		$ligne= $(this);
		$position= $(this).index();
		
		$ligne.toggleClass("fond_orange");
		
		$b= $ligne.hasClass("fond_orange");
		
		if($b) {
			$(".modifierCite .selectionnerCite .header").css("display", "block");
		
			$(".modifierCite .selectionnerCite .corps").prepend(
				"<div class='cite cite"+$position+"'>"+
				
					"<div class='bordure'>"+
						">>--------------- Cite numero <span class='numero'>"+$position+"</span> ---------------<<"+
					"</div>"+
					
					
					"<form method='post' action='#'>"+
						
						"<fieldset>"+
							"<legend>Modifier la photo de profil pour votre cite</legend>"+
					
							"<img src='img/cite-default.jpg' alt='image' width='30%' />"+
				
							"<br />"+
							"<input type='file' name='image' id='image' />"+
						"</fieldset>"+
						
						
					
						"<fieldset>"+
							"<legend>Modifier l'identifiant de votre cite</legend>"+
					
							"<input type='text' name='code' id='code' value='"+$("table tr:eq("+$position+") td:eq(1)").text()+"' placeholder='Code' />"+
							"<input type='text' name='nom' id='nom' value='"+$("table tr:eq("+$position+") td:eq(2)").text()+"' placeholder='nom' />"+
						"</fieldset>"+
						
						
						"<fieldset>"+
							"<legend>Modifier l'emplacement de votre cite</legend>"+
					
							"<input type='text' name='pays' id='pays' value='"+$("table tr:eq("+$position+") td:eq(3)").text()+"' placeholder='Pays' />"+
							"<input type='text' name='ville' id='ville' value='"+$("table tr:eq("+$position+") td:eq(4)").text()+"' placeholder='Ville' />"+
						"</fieldset>"+
				
				
				
						"<br />"+
						"<fieldset>"+
							"<legend>Description</legend>"+
					
							"<textarea rows='10' cols='30'>"+$("table tr:eq("+$position+") td:eq(5)").text()+"</textarea>"+
						"</fieldset>"+
						
						
				
						"<br />"+
						"<input type='reset' name='effacer' class='reinitialiser' value='Reinitialiser' />"+
						"<input type='submit' name='modifier' class='modifier' value='Modifier' />"+
					"</form>"+
					"<div class='bordure'>"+
						">>----------------------------------------------------------------------------------------<<"+
					"</div>"+
					"<div class='effacer'>"+
						"<span class='art-button'>Effacer</span>"+
					"</div>"+
				"</div>"
			);
		}
		else {
			$(".modifierCite .selectionnerCite .corps .cite" + $position).remove();
			
			if($(".modifierCite .selectionnerCite .corps .cite").length <= 0) {
				$(".modifierCite table tr").removeClass("fond_orange");
				$(".modifierCite .selectionnerCite .header").css("display", "none");
			}
		}
		
		
		//--------------> Evenement sur le bouton modifier
		$(".modifierCite .selectionnerCite .corps .cite .modifier").click(function (e) {
			//e.preventDefault();
			//$(".modifierEmploi table").load($(this).attr('href'));
		});
		
		
		
		
		$(".modifierCite .selectionnerCite .corps .cite .effacer span").click(function () {
			$(this).parent().parent().remove();
			$(".modifierCite table tr:eq("+$(this).parent().parent().find(".numero").text()+")").removeClass("fond_orange");
			
			if($(".modifierCite .selectionnerCite .corps .cite").length <= 0) {
				$(".modifierCite table tr").removeClass("fond_orange");
				$(".modifierCite .selectionnerCite .header").css("display", "none");
			}
		});
		
	});
	
	
	$(".modifierCite .selectionnerCite .header .header1 span").click(function () {
		$(".modifierCite .selectionnerCite .corps").empty();
		$(".modifierCite table tr").removeClass("fond_orange");
		$(".modifierCite .selectionnerCite .header").css("display", "none");
	});
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/********************************************Supprimer*******************************/
	pagination(5, ".supprimerCite table .corps", ".supprimerCite .pagination", 3);
	
	$(".supprimerCite table tr").click(function () {
		$(this).toggleClass("fond_orange");
	});
	
	$(".supprimerCite .selectionnerCite .boutonSupprimer span").click(function () {
		taille= $(".supprimerCite table tr").length;
		
		for(i= 0; i<taille; i++) {
			if ($(".supprimerCite table tr:eq("+i+")").hasClass("fond_orange")) {
				$(".supprimerCite table tr:eq("+i+")").remove();
			}
		}
		
	});
	
	
});