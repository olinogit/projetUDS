$(document).ready(function () {
   var userAgent = navigator.userAgent.toLowerCase();
   
   jQuery.browser = {
      version: (userAgent.match( /.+(?:rv|it|ra|ie|me)[\/: ]([\d.]+)/ ) || [])[1],
      chrome: /chrome/.test( userAgent ),
      safari: /webkit/.test( userAgent ) && !/chrome/.test( userAgent ),
      opera: /opera/.test( userAgent ),
      msie: /msie/.test( userAgent ) && !/opera/.test( userAgent ),
      mozilla: /mozilla/.test( userAgent ) && !/(compatible|webkit)/.test( userAgent )
   };
   
   var lblNavigateur = 'Navigateur : ';
   if ( $.browser.msie ){
      lblNavigateur += 'Internet explorer';
   }
   else if ( $.browser.chrome ){
      lblNavigateur += 'Chrome';
   }
   else if ( $.browser.mozilla ){
      lblNavigateur += 'Mozilla Firefox';
   }
   else if ( $.browser.opera ){
      lblNavigateur += 'Opera';
   }
   else{
      lblNavigateur += 'Autre navigateur';
   }
   lblNavigateur += ' | version : ' + $.browser.version;
   /*$('').html(lblNavigateur);
   alert(lblNavigateur);*/
});