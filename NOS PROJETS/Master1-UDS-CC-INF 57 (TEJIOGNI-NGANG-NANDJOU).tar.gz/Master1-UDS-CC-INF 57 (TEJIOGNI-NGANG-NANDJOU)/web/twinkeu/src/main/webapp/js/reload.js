$(document).ready(function() {
	console.log("La page est prete");
	$.ajax({
		url: 'http://localhost:8080/twinkeu/ConnexionServlet?action=reload',
		type: 'get',
		dataType: 'json',
		success: function(data) {
			console.log(data);
			for(var i=0;i<data.length;i++){
				$('#selectCite').append('<option value="'+data[i].nom+'">'+data[i].nom+'</option>');
			}
		},
		error: function(data) {
			console.log("Error");
		}
	});
	
});