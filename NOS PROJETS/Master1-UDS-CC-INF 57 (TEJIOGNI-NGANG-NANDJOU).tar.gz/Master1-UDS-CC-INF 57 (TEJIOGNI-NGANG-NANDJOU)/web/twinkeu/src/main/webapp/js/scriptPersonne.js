
/*

	Script pour la gestion de l'IHM des personnes et autres petites fonctinnalit�s dans le site 

*/


$(document).ready(function() {


	/**************Gestion des pages HTML li�es au bouton de navigation*********************/
	
	/***************Fin de la gestion des pages li�s au bouton de navigation***************/
	
	
	
	
	
	
	
	
	
	
	
	
	/***************************Gestion des boutons de navigation******************************/
	
	//-----------------------> Dans le nav 
	$("nav ul .lien1").click(function() {
		$("nav ul li a").removeClass("active");
		$(this).children().addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien1 span").addClass("couleur-orange");
		
		$("article .corps").load("home.jsp");
	});
	
	$("nav ul .lien2").click(function() {
		$("nav ul li a").removeClass("active");
		$(this).children().addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien2 span").addClass("couleur-orange");
		
		$("article .corps").load("about.jsp");
	});
	
	$("nav ul .lien3").click(function() {
		$("nav ul li a").removeClass("active");
		$(this).children().addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien3 span").addClass("couleur-orange");
		
		$("article .corps").load("services.jsp");
	});
	
	$("nav ul .lien4").click(function() {
		$("nav ul li a").removeClass("active");
		$(this).children().addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien4 span").addClass("couleur-orange");
		
		$("article .corps").load("produits.jsp");
	});
	
	$("nav ul .lien5").click(function() {
		$("nav ul li a").removeClass("active");
		$(this).children().addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien5 span").addClass("couleur-orange");
		
		$("article .corps").load("contacts.jsp");
	});
	
	//-----------> Dans le footer
	$("footer .lien1").click(function() {
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien1 span").addClass("couleur-orange");
		
		$("nav ul li a").removeClass("active");
		$("nav ul .lien1 a").addClass("active");
		
		$("article .corps").load("home.jsp");
	});
	
	$("footer .lien2").click(function() {
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien2 span").addClass("couleur-orange");
		
		$("nav ul li a").removeClass("active");
		$("nav ul .lien2 a").addClass("active");
		
		$("article .corps").load("about.jsp");
	});
	
	$("footer .lien3").click(function() {
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien3 span").addClass("couleur-orange");
		
		$("nav ul li a").removeClass("active");
		$("nav ul .lien3 a").addClass("active");
		
		$("article .corps").load("services.jsp");
	});
	
	$("footer .lien4").click(function() {
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien4 span").addClass("couleur-orange");
		
		$("nav ul li a").removeClass("active");
		$("nav ul .lien4 a").addClass("active");
		
		$("article .corps").load("produits.jsp");
	});
	
	$("footer .lien5").click(function() {
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien5 span").addClass("couleur-orange");
		
		$("nav ul li a").removeClass("active");
		$("nav ul .lien5 a").addClass("active");
		
		$("article .corps").load("contacts.jsp");
	});
	
	/*************************Fin de la gestion de la navigation***************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*********************************Gestion des blocks*******************************/
	//---------------> Les blocks
	$(".alerte").css("cursor", "pointer");
	$(".profil").css("cursor", "pointer");
	$(".block div:first-child").css("cursor", "pointer");
	$(".block div:last-child").hide();
	
	$(".alerte div:first-child").click(function() {
		$(".profil div:first-child h3").css("color", "white");
		$(".block div:first-child h3").css("color", "white");
		$(this).children().css("color", "rgb(255, 111, 12)");
		
		$(".alerte div:last-child").slideToggle("slow");
	});
	
	$(".profil div:first-child").click(function() {
		$(".alerte div:first-child h3").css("color", "white");
		$(".block div:first-child h3").css("color", "white");
		$(this).children().css("color", "rgb(255, 111, 12)");
		
		$(".profil div:last-child").slideToggle("slow");
	});
	
	
	$(".block div:first-child").click(function() {
		$(".alerte div:first-child h3").css("color", "white");
		$(".profil div:first-child h3").css("color", "white");
		$(".block div:first-child h3").css("color", "white");
		$(this).children().css("color", "rgb(255, 111, 12)");
	
		var slide= $(this).next("div");
		
		if(!slide.is(":visible")) {
			$(".block div:last-child").slideUp(1000);
			slide.slideDown("slow");
		}
		else {
			slide.slideToggle("slow");
		}
	});
	
	
	
	//---------------------> Contenu des blocks
	
	//*********** Alerte
	$(".alerte .divAlerte").click(function() {
		//$("article .corps").load("geolocalisation.jsp");
	});
	
	
	
	
	//*********** Statut
	$(".block1 .statut .etudiant").click(function() {
		$("article .corps").load("statutEtudiant.jsp");
	});
	
	$(".block1 .statut .concierge").click(function() {
		$("article .corps").load("statutConcierge.jsp");
	});
	
	
	
	
	
	
	
	//*********** Profil
	$(".block2_1 .profil .consulter").click(function() {
		$("article .corps").load("profilConsulter_Personne.jsp");
	});
	
	$(".block2_2 .profil .consulter").click(function() {
		$("article .corps").load("profilConsulter_Etudiant.jsp");
	});
	
	$(".block2_1 .profil .modifier").click(function() {
		$("article .corps").load("profilModifier_Personne.jsp");
	});
	
	$(".block2_2 .profil .modifier").click(function() {
		$("article .corps").load("profilModifier_Etudiant.jsp");
	});
	
	$(".block2_1 .profil .supprimer").click(function() {
		alert("Au revoir et merci d'avoir essayez notre site")
	});
	
	$(".block2_2 .profil .supprimer").click(function() {
		alert("Au revoir et merci d'avoir essayez notre site")
	});
	
	
	
	
	//*********** Emploi du temps
	$(".block3_1 .emploi .consulter").click(function() {
		$("article .corps").load("emploiConsulter_Etudiant.jsp");
	});
	
	
	
	
	$(".block3 .emploi .ajouter").click(function() {
		$("article .corps").load("emploiAjouter.jsp");
	});
	
	$(".block3 .emploi .consulter").click(function() {
		$("article .corps").load("emploiConsulter.jsp");
	});
	
	$(".block3 .emploi .modifier").click(function() {
		$("article .corps").load("emploiModifier.jsp");
	});
	
	$(".block3 .emploi .supprimer").click(function() {
		$("article .corps").load("emploiSupprimer.jsp");
	});
	
	$(".block3 .emploi .imprimer").click(function() {
		
	});
	
	
	
	//*********** Note
	$(".block4_1 .note .consulter").click(function() {
		$("article .corps").load("noteConsulter_Etudiant.jsp");
	});
	
	
	
	
	
	
	
	$(".block4 .note .ajouter").click(function() {
		$("article .corps").load("noteAjouter.jsp");
	});
	
	$(".block4 .note .consulter").click(function() {
		$("article .corps").load("noteConsulter.jsp");
	});
	
	$(".block4 .note .modifier").click(function() {
		$("article .corps").load("noteModifier.jsp");
	});
	
	$(".block4 .note .supprimer").click(function() {
		$("article .corps").load("noteSupprimer.jsp");
	});
	
	$(".block4 .note .imprimer").click(function() {
		
	});
	
	
	
	
	
	
	//*********** Cit�
	$(".block5 .cite .ajouter").click(function() {
		$("article .corps").load("citeAjouter.jsp");
	});
	
	$(".block5 .cite .consulter").click(function() {
		$("article .corps").load("citeConsulter.jsp");
	});
	
	$(".block5 .cite .modifier").click(function() {
		$("article .corps").load("citeModifier.jsp");
	});
	
	$(".block5 .cite .supprimer").click(function() {
		$("article .corps").load("citeSupprimer.jsp");
	});
	
	$(".block5 .cite .imprimer").click(function() {
		
	});
	
	
	
	
	
	//*********** Actualit�
	$(".block6 .actu .ajouter").click(function() {
		$("article .corps").load("actuAjouter.jsp");
	});
	
	$(".block6 .actu .consulter").click(function() {
		$("article .corps").load("actuConsulter.jsp");
	});
	
	$(".block6 .actu .modifier").click(function() {
		$("article .corps").load("actuModifier.jsp");
	});
	
	$(".block6 .actu .supprimer").click(function() {
		$("article .corps").load("actuSupprimer.jsp");
	});
	
	$(".block6 .actu .imprimer").click(function() {
		
	});
	
	
	
	
	
	
	//*********** Comptes
	$(".block7 .compte .ajouter").click(function() {
		$("article .corps").load("compteAjouter.jsp");
	});
	
	$(".block7 .compte .consulter").click(function() {
		$("article .corps").load("compteConsulter.jsp");
	});
	
	$(".block7 .compte .modifier").click(function() {
		$("article .corps").load("compteModifier.jsp");
	});
	
	$(".block7 .compte .supprimer").click(function() {
		$("article .corps").load("compteSupprimer.jsp");
	});
	
	$(".block7 .compte .imprimer").click(function() {
		
	});
	
	/****************************Fin de la gestion des blocks*******************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/************************************Gestion des actualit�s******************************/
	$("article .corps .bouton-suite").click(function() {
		$("nav ul li a").removeClass("active");
		$("nav ul .lien2 a").addClass("active");
		
		$("footer .lien span").removeClass("couleur-orange");
		$("footer .lien2 span").addClass("couleur-orange");
		
		$("article .corps").load("about.jsp .corps");
	});
	/******************************Fin de la gestion des actualit�s**************************/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*******************Fonction pour recharger une page web**************************/
	function recharge(str) {
		document.location= str;
	}
	
	
});