package jpa;


import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;

@Entity
public class Actualite{

	/**
	 * Mapping objet relationnel de la classe Actualité
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id_actualite;
	private String titre;
	@Lob
	@Basic (fetch=FetchType.LAZY)
	private byte[] photo;
	private String contenu;

	
//	Une actualité est publiée par un et un seul (1,1) administrateur
	@OneToOne
	@JoinColumn(name="id_admin_fk", nullable = false)
	private Administrateur administrateur;
	

	
	
	
	
	
	
	
	
	//	Génération des constructeurs
	public Actualite(String titre, byte[] photo, String contenu) {
		this.titre = titre;
		this.photo = photo;
		this.contenu = contenu;
	}

	public Actualite() {}

	
//	Génération des accesseurs
	public long getId_actualite() {
		return id_actualite;
	}

	public void setId_actualite(long id_actualite) {
		this.id_actualite = id_actualite;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public Administrateur getAdministrateur() {
		return administrateur;
	}

	public void setAdministrateur(Administrateur administrateur) {
		this.administrateur = administrateur;
	}
}