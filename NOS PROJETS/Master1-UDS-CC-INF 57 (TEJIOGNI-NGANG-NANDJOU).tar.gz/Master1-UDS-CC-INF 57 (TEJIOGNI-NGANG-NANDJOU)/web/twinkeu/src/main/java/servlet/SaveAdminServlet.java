﻿package servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Cite;
import ejb.AdminEJB;

/**
 * Servlet implementation class SaveCiteServlet
 */
public class SaveAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	AdminEJB adminEJB;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String login = request.getParameter("login");
		String password = request.getParameter("password");
		
		Administrateur admin = new Administrateur();
		admin.setLogin(login);
		admin.setPassword(password);

		adminEJB.ajoutAdmin(admin);
		getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		
	}

}
