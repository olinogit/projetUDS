package ejb;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Alerte;
import jpa.Cite;
import jpa.EmploiTemps;
import jpa.Etudiant;
import jpa.Note;



@Stateless
public class EtudiantEJB {

	@PersistenceContext(unitName = "twinkeuDS")
	EntityManager em;


	//	Connexion d'un étudiant à partir de son login et par mot de passe
	public Etudiant connexionEtudiant(String login, String password){
		Etudiant etudiant = null;
		try {
			Query query = em.createQuery("SELECT e FROM Etudiant e WHERE e.login=:param1 AND e.password=:param2");
			query.setParameter("param1", login);
			query.setParameter("param2", password);
			etudiant = (Etudiant)query.getSingleResult();
		} catch (Exception e) {
			// TODO: handle exception
			etudiant = null;
		}
		return etudiant;
	}

	//	Enregistrement d'un profil étudiant
	public void creerProfilEtudiant(Etudiant etudiant, Cite cite) {
		// TODO Auto-generated method stub
		etudiant.setCite(cite);
		em.persist(etudiant);

	}

	public void supprimerProfilEtudiant(Etudiant etudiant) {
		// TODO Auto-generated method stub

	}

	
//	Méthode pour modifier un étudiant
	
	public void modifierProfilEtudiant(Etudiant e1, Etudiant e2) {
		// TODO Auto-generated method stub
		em.merge(e1);
		e1.setNom(e2.getNom());
		em.persist(e1);
		

	}

	public Etudiant consulterProfilEtudiant(String matricule) {
		// TODO Auto-generated method stub
		Etudiant etudiant = em.find(Etudiant.class, matricule);
		return etudiant;
	}

	
//	Consultation d'un emploi de temps suivant le code d'un cours
	public List<EmploiTemps> consulterEmploiTemps(String code_cours) {
		// TODO Auto-generated method stub
		List<EmploiTemps> emploiTemps = null;
		try {
			Query requete = em.createQuery("SELECT e FROM Emploitemps e WHERE e.codecours=:code_cours ");
			requete.setParameter("code_cours", code_cours);
			emploiTemps = requete.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			emploiTemps = null;
		}
		return emploiTemps;
	}

	
	
//	Affichage de tous les emplois de temps du niveau de l'etudiant
	public List<EmploiTemps> listeEmploiTemps(String niveau) {
		// TODO Auto-generated method stub
		List<EmploiTemps> emploiTemps = null;
		try {
			Query requete = em.createQuery("SELECT e FROM Emploitemps e WHERE e.niveau=:param");
			requete.setParameter("param", niveau);
			emploiTemps = requete.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			emploiTemps = null;
		}
		return emploiTemps;
	}

	
	
	
//	Recherche des notes d'un etudiant de matricule donné
	public List<Note> consulterNote(String matricule) {
		// TODO Auto-generated method stub
		List<Note> notes= null;
		try {
			Query requete = em.createQuery("SELECT n FROM Note n WHERE n.etudiant.matricule=:param1");
			requete.setParameter("param1", matricule);
			notes = requete.getResultList();	
		} catch (Exception e) {
			notes = null;
		}
		return notes;
	}
	
	
	
//	Recherche des toutes les notes de l'application
	public List<Note> listeNote() {
		// TODO Auto-generated method stub
		List<Note> notes= null;
		try {
			Query requete = em.createQuery("SELECT n FROM Note n");
			notes = requete.getResultList();	
		} catch (Exception e) {
			notes = null;
		}
		return notes;
	}


	//	Recherche d'une actualite suivant un mot clé
	public List<Actualite> consulterActualite(String motCle) {
		// TODO Auto-generated method stub
		Query requete = em.createQuery("SELECT a FROM Actualite a WHERE UPPER(a.titre) LIKE : motCle "
				+ "OR UPPER(a.contenu) LIKE : motCle");
		requete.setParameter("motCle", "%"+motCle.toUpperCase()+"%");
		List<Actualite> actualites = requete.getResultList();
		return actualites;
	}

	//	Recherche de toutes les actualites du site
	public List<Actualite> listeActualite() {
		// TODO Auto-generated method stub
		List<Actualite> actualites = null;
		try {
			Query requete = em.createQuery("SELECT a FROM Actualite a");
			actualites = requete.getResultList();

		} catch (Exception e) {
			// TODO: handle exception
			actualites = null;
		}
		return actualites;
	}


//  Methode pour enregistrer une alerte
	public Etudiant envoyerAlerte(Alerte alerte, Etudiant etudiant) {
		// TODO Auto-generated method stub
		alerte.setEtudiant(etudiant);
		em.persist(alerte);
		return etudiant;
	}
	
	
//	Methode pour recuperer une alerte de la base de données, renvoi de la dernier alerte envoyee
	public List<Alerte> renvoyerAlerte() {
		// TODO Auto-generated method stub
		List<Alerte> alertes= null;
		try {
			Query requete = em.createQuery("SELECT a FROM Alerte a");
			alertes = requete.getResultList();	
		} catch (Exception e) {
			alertes = null;
		}
		return alertes;
	}
	
	
	

// Methode pour rechercher suivant son code
	public Cite rechercherCite(long code_cite) {
		// TODO Auto-generated method stub
		Cite cite = null;
		try {
			cite = em.find(Cite.class, code_cite);			
		} catch (Exception e) {
			// TODO: handle exception
			cite = null;
		}
		return cite;
	}
	
	// Methode pour rechercher une cite suivant son nom
		public List<Cite> rechercherCite(String nom) {
			// TODO Auto-generated method stub
			List<Cite> cites = null;
			try {
				Query requete = em.createQuery("SELECT c FROM Cite c WHERE c.nom=:param");
				requete.setParameter("param", nom);
				cites = requete.getResultList();	
			} catch (Exception e) {
				// TODO: handle exception
				cites = null;
			}
			return cites;
		}
		
		
		
//		Recherche d'un etudiant connaissant son matricule
		public Etudiant rechercherEtudiant(String matricule) {
			// TODO Auto-generated method stub
			Etudiant etudiant = em.find(Etudiant.class, matricule);
			return etudiant;
		}
		
}
