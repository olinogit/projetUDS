package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Alerte;
import jpa.Cite;
import jpa.EmploiTemps;
import jpa.Etudiant;
import jpa.Note;


@Stateless
public class AdminEJB {

	@PersistenceContext(unitName = "twinkeuDS")
	EntityManager em;


	//	Connexion d'un administrateur à partir de son login et et son mot de passe

	public Administrateur connexionAdmin(String login, String password){
		Administrateur admin = null;
		try {
			Query query = em.createQuery("SELECT a FROM Administrateur a WHERE a.login=:param1 AND a.password=:param2");
			query.setParameter("param1", login);
			query.setParameter("param2", password);
			admin = (Administrateur)query.getSingleResult();			
		} catch (Exception e) {
			// TODO: handle exception
			admin = null;
		}
		return admin;
	}


	public void ajoutAdmin(Administrateur admin) {
		// TODO Auto-generated method stub
		em.persist(admin);
	}
	
	

	public Administrateur rechercherAdmin(String login) {
		// TODO Auto-generated method stub
		Administrateur admin = em.find(Administrateur.class, login);
		return admin;
	}

	public void modifierAdmin(Administrateur admin) {
		// TODO Auto-generated method stub

	}

	public void ajoutActualite(Actualite actualite, Administrateur admin) {
		// TODO Auto-generated method stub
		actualite.setAdministrateur(admin);
		em.persist(actualite);
	}

	public Actualite rechercherActualite(String motCle) {
		// TODO Auto-generated method stub
		Actualite actualite = em.find(Actualite.class, motCle);
		return actualite;
	}

	public void modifierActualite(Actualite actualite) {
		// TODO Auto-generated method stub

	}

	public void supprimerActualite(Actualite actualite) {
		// TODO Auto-generated method stub
		em.remove(em.merge(actualite));
	}

	public void ajoutCite(Cite cite) {
		// TODO Auto-generated method stub
		em.persist(cite);
	}

	
//	Methode pour rechercher une cite connaissant son code
	public Cite rechercherCite(long code_cite) {
		// TODO Auto-generated method stub
		Cite cite = null;
		try {
			cite = em.find(Cite.class, code_cite);			
		} catch (Exception e) {
			// TODO: handle exception
			cite = null;
		}
		return cite;
	}
	
	
//	Methode pour rechercher une cite connaissant son nom
	public Cite rechercherCite(String nom) {
		// TODO Auto-generated method stub
		Cite cite = null;
		try {
			Query query = em.createQuery("SELECT c FROM Cite c WHERE c.nom=:param1");
			query.setParameter("param1", nom);
			cite = (Cite)query.getSingleResult();			
		} catch (Exception e) {
			// TODO: handle exception
			cite = null;
		}
		return cite;
	}
	
	

	public void modifierCite(Cite cite) {
		// TODO Auto-generated method stub

	}


	//	Méthode permettant de rechercher toutes les cites de la base
	public List<Cite> listeCite() {
		// TODO Auto-generated method stub
		List<Cite> listCite = null;
		try {
			Query requete = em.createQuery("SELECT c FROM Cite c ");
			listCite = requete.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			listCite = null;
		}
		return listCite;
	}


	public void supprimerCite(Cite cite) {
		// TODO Auto-generated method stub
		em.remove(em.merge(cite));
	}

	public void ajoutNote(Note note, Etudiant etudiant) {
		// TODO Auto-generated method stub
		note.setEtudiant(etudiant);
		em.persist(note);
	}

	public Note rechercherNote(long id_note) {
		// TODO Auto-generated method stub
		Note note = em.find(Note.class, id_note);
		return note;
	}

	public void modifierNote(Note note) {
		// TODO Auto-generated method stub

	}

	public void supprimerNote(Note note) {
		// TODO Auto-generated method stub
		em.remove(em.merge(note));
	}

	public void ajoutEmploiTemps(EmploiTemps emploiTemps, Administrateur admin) {
		// TODO Auto-generated method stub
		emploiTemps.setAdministrateur(admin);
		em.persist(emploiTemps);
	}

	public EmploiTemps rechercherEmploiTemps(long id_empTemps) {
		// TODO Auto-generated method stub
		EmploiTemps emploiTemps = em.find(EmploiTemps.class, id_empTemps);
		return emploiTemps;
	}

	public void modifierEmploiTemps(EmploiTemps emploiTemps) {
		// TODO Auto-generated method stub

	}

	public void supprimerEmploiTemps(EmploiTemps emploiTemps) {
		// TODO Auto-generated method stub
		em.remove(em.merge(emploiTemps));
	}


	public void ajoutEtudiant(Etudiant etudiant) {
		// TODO Auto-generated method stub
		em.persist(etudiant);
	}

	public Etudiant rechercherEtudiant(String matricule) {
		// TODO Auto-generated method stub
		Etudiant etudiant = em.find(Etudiant.class, matricule);
		return etudiant;
	}

	public void modifierEtudiant(Etudiant etudiant) {
		// TODO Auto-generated method stub

	}

	public void supprimerEtudiant(Etudiant etudiant) {
		// TODO Auto-generated method stub
		em.remove(em.merge(etudiant));
	}


	public void envoyerAlerte(Alerte alerte, Etudiant etudiant) {
		// TODO Auto-generated method stub
		
		alerte.setEtudiant(etudiant);
		em.persist(alerte);
	}

	public void supprimerAlerte(Alerte alerte) {
		// TODO Auto-generated method stub
		em.remove(em.merge(alerte));
	}

	public void modifierAlerte(Alerte alerte) {
		// TODO Auto-generated method stub

	}

	public Alerte recherherAlerte(long id_alerte) {
		// TODO Auto-generated method stub
		Alerte alerte = em.find(Alerte.class, id_alerte);
		return alerte;
	}


	//	Méthode permettant de rechercher tous les etudiant de la base
	public List<Etudiant> listeEtudiant() {
		// TODO Auto-generated method stub
		List<Etudiant> listEtudiant = null;
		try {
			Query requete = em.createQuery("SELECT e FROM Etudiant e ");
			listEtudiant = requete.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			listEtudiant= null;
		}
		return listEtudiant;
	}

	
//	Recherche des notes de tous les etudiants de la base de donnees
	public List<Note> listeNotes() {
		// TODO Auto-generated method stub
		List<Note> notes = null;
		try {
			Query requete = em.createQuery("SELECT n FROM Note n");
			notes = requete.getResultList();	
		} catch (Exception e) {
			notes = null;
		}
		return notes;
	}
	
	
//	Recuperation de tous les emplois de temps du système
	public List<EmploiTemps> listeEmploiTemps() {
		// TODO Auto-generated method stub
		List<EmploiTemps> emploiTemps = null;
		try {
			Query requete = em.createQuery("SELECT e FROM Emploitemps e ");
			emploiTemps = requete.getResultList();
		} catch (Exception e) {
			// TODO: handle exception
			emploiTemps = null;
		}
		return emploiTemps;
	}
	
	
//	Recherche de toutes les actualites du site
	public List<Actualite> listeActualite() {
		// TODO Auto-generated method stub
		List<Actualite> actualites = null;
		try {
			Query requete = em.createQuery("SELECT a FROM Actualite a");
			actualites = requete.getResultList();

		} catch (Exception e) {
			// TODO: handle exception
			actualites = null;
		}
		return actualites;
	}

}
