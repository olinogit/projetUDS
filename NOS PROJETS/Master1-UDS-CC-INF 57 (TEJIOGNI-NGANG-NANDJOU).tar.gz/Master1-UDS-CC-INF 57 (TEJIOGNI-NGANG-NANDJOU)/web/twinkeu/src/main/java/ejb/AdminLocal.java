package ejb;

import javax.ejb.Local;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Alerte;
import jpa.Cite;
import jpa.EmploiTemps;
import jpa.Etudiant;
import jpa.Note;

@Local
public interface AdminLocal{
	
	
//	Gestion d'un administrateur
	public void ajoutAdmin(Administrateur admin);
	public Administrateur rechercherAdmin(long id_admin);
	public void modifierAdmin(Administrateur admin);
	
//	Gestion d'une actualité
	public void ajoutActualite(Actualite actualite);
	public Actualite rechercherActualite(String motCle);
	public void modifierActualite(Actualite actualite);
	public void supprimerActualite(Actualite actualite);
	
//	Gestion d'une cite
	public void ajoutCite(Cite cite);
	public Cite rechercherCite(long code_cite);
	public void modifierCite(Cite cite);
	public void supprimerCite(Cite cite);
	
//	Gestion d'une note
	public void ajoutNote(Note note);
	public Note rechercherNote(long id_note);
	public void modifierNote(Note note);
	public void supprimerNote(Note note);
	
//	Gestion d'un emploi de temps
	public void ajoutEmploiTemps(EmploiTemps emploiTemps);
	public EmploiTemps rechercherEmploiTemps(long id_empTemps);
	public void modifierEmploiTemps(EmploiTemps emploiTemps);
	public void supprimerEmploiTemps(EmploiTemps emploiTemps);
	
//	Gestion d'un compte Etudiant
	public void ajoutEtudiant(Etudiant etudiant);
	public Etudiant rechercherEtudiant(String matricule);
	public void modifierEtudiant(Etudiant etudiant);
	public void supprimerEtudiant(Etudiant etudiant);
	
//	Gestion d'une alerte
	public void envoyerAlerte(Alerte alerte);
	public void supprimerAlerte (Alerte alerte);
	public void modifierAlerte(Alerte alerte);
	public Alerte recherherAlerte(long id_alerte);
		
	
}