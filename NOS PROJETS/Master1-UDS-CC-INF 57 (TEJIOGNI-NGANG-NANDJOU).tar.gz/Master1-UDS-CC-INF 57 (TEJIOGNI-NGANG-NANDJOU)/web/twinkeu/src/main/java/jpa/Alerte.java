package jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Alerte{
	

	/**
	 * Mapping objet relationnel de la classe Alerte
	 */
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id_alerte;
	private String contenu;
	private float latitude;
	private float longitude;
	
	@OneToOne
	@JoinColumn(name="matricule_fk", nullable=false)
	private Etudiant etudiant;
	

	
	
	
	
	

	//	Génération des constructeurs
	public Alerte(String contenu, float latitude, float longitude) {
		this.contenu = contenu;
		this.latitude = latitude;
		this.longitude = longitude;
	}

	public Alerte() {}


	// Génération des accesseurs
	public float getId_alerte() {
		return id_alerte;
	}

	public void setId_alerte(long id_alerte) {
		this.id_alerte = id_alerte;
	}

	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public float getLatitude() {
		return latitude;
	}

	public void setLatitude(float latitude) {
		this.latitude = latitude;
	}

	public float getLongitude() {
		return longitude;
	}

	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}


	public Etudiant getEtudiant() {
		return etudiant;
	}

	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}
	
}