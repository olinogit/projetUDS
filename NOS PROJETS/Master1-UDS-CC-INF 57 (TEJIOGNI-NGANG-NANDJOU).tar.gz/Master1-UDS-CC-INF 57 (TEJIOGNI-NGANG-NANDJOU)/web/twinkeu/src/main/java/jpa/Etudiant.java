package jpa;



import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToOne;



@Entity
public class Etudiant{


	/**
	 * Mapping objet/relationnel de la classe Etudiant
	 */

	@Id
	@JoinColumn(nullable=false)
	private String matricule;

	private String niveau;
	private String filiere;
	private String nom;
	private String prenom;
	private String date_naissance;
	private String lieu_naissance;
	private String sexe;

	@Lob
	@Basic (fetch=FetchType.LAZY)
	private byte[] photo;
	
	private long cni;
	private long telephone;
	private String mail;
	private String login;
	private String password;
	private String pays;
	private String ville;
	private String quartier;
	private boolean statut;
	private boolean etat;
	

	private String Description;


	@OneToOne
	@JoinColumn(name="code_cite_fk", nullable=false)
	private Cite cite;












	//	Génération des constructeurs


	public Etudiant() {}



	public Etudiant(String matricule, String niveau, String filiere,
			String nom, String prenom, String date_naissance,
			String lieu_naissance, String sexe, byte[] photo, long cni,
			long telephone, String mail, String login, String password,
			String pays, String ville, String quartier, boolean statut,
			String description, Cite cite) {
		this.matricule = matricule;
		this.niveau = niveau;
		this.filiere = filiere;
		this.nom = nom;
		this.prenom = prenom;
		this.date_naissance = date_naissance;
		this.lieu_naissance = lieu_naissance;
		this.sexe = sexe;
		this.photo = photo;
		this.cni = cni;
		this.telephone = telephone;
		this.mail = mail;
		this.login = login;
		this.password = password;
		this.pays = pays;
		this.ville = ville;
		this.quartier = quartier;
		this.statut = statut;
		Description = description;
		this.cite = cite;
	}



	//	Génération des accesseurs
	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getNiveau() {
		return niveau;
	}

	public void setNiveau(String niveau) {
		this.niveau = niveau;
	}

	public String getFiliere() {
		return filiere;
	}

	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getDate_naissance() {
		return date_naissance;
	}

	public void setDate_naissance(String date_naissance) {
		this.date_naissance = date_naissance;
	}

	public String getLieu_naissance() {
		return lieu_naissance;
	}

	public void setLieu_naissance(String lieu_naissance) {
		this.lieu_naissance = lieu_naissance;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	public byte[] getPhoto() {
		return photo;
	}

	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}

	public long getCni() {
		return cni;
	}

	public void setCni(long cni) {
		this.cni = cni;
	}

	public long getTelephone() {
		return telephone;
	}

	public void setTelephone(long telephone) {
		this.telephone = telephone;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPays() {
		return pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getQuartier() {
		return quartier;
	}

	public void setQuartier(String quartier) {
		this.quartier = quartier;
	}

	public boolean isStatut() {
		return statut;
	}

	public void setStatut(boolean statut) {
		this.statut = statut;
	}
	
	public boolean isEtat() {
		return etat;
	}

	public void setEtat(boolean etat) {
		this.etat = etat;
	}
	

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Cite getCite() {
		return cite;
	}

	public void setCite(Cite cite) {
		this.cite = cite;
	}


}