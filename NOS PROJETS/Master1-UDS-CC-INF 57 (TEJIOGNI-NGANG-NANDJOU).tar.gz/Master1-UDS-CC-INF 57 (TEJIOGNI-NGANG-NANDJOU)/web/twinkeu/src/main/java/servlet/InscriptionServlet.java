package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Cite;
import jpa.EmploiTemps;
import jpa.Etudiant;
import jpa.Note;
import ejb.AdminEJB;
import ejb.EtudiantEJB;

/**
 * Servlet implementation class InscriptionServlet
 */
public class InscriptionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	@EJB
	AdminEJB adminEJB;
	@EJB
	EtudiantEJB etudiantEJB;
	
	
    public InscriptionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String VUE= "";
	    String action= "";
	    
		PrintWriter out = response.getWriter();
		
		action= request.getParameter("action");
		
		
		/***************Gestion des incriptions en general**************/
		if(action.equals("Inscription")) {
			
			Etudiant etudiant= new Etudiant();
			Cite cite= new Cite();
			
			String nom= request.getParameter("nom");
			String prenom= request.getParameter("prenom");
			String sexe= request.getParameter("sexe");
			String dateNaiss= request.getParameter("dateNaiss");
			String lieuNaiss= request.getParameter("lieuNaiss");
			String fil= request.getParameter("fil");
			String niv= request.getParameter("niv");
			String mat= request.getParameter("mat");
			long cni= Integer.parseInt(request.getParameter("cni"));
			String loginInscription= request.getParameter("loginInscription");
			String passInscription= request.getParameter("passInscription");
			String pays= request.getParameter("pays");
			String ville= request.getParameter("ville");
			String quartier= request.getParameter("quartier");
			long telephone= Integer.parseInt(request.getParameter("telephone"));
			String boitemail= request.getParameter("boitemail");
			
			
			String nomCite= request.getParameter("cite");
			
			cite= adminEJB.rechercherCite(nomCite);
			
			
			String description= request.getParameter("description");
			
			etudiant.setNom(nom);
			etudiant.setPrenom(prenom);
			etudiant.setSexe(sexe);
			etudiant.setDate_naissance(dateNaiss);
			etudiant.setLieu_naissance(lieuNaiss);
			etudiant.setFiliere(fil);
			etudiant.setNiveau(niv);
			etudiant.setMatricule(mat);
			etudiant.setCni(cni);
			etudiant.setLogin(loginInscription);
			etudiant.setPassword(passInscription);
			etudiant.setPays(pays);
			etudiant.setVille(ville);
			etudiant.setQuartier(quartier);
			etudiant.setTelephone(telephone);
			etudiant.setMail(boitemail);
			//etudiant.setCite(cite);   
			etudiant.setEtat(true);
			etudiant.setStatut(true);
			etudiant.setDescription(description);
			
			etudiantEJB.creerProfilEtudiant(etudiant, cite);
			
			VUE= "/index.jsp";
			
		}
		
		
		
		
		
		
		
		/*******************Gestion des ajouts de cité****************/
		if(action.equals("ajoutCite")) {
			
			String etatCite= "";
			Cite cite= new Cite();
			 
			long code= Integer.parseInt(request.getParameter("code"));
			String nom= request.getParameter("nom");
			String pays= request.getParameter("pays");
			String ville= request.getParameter("ville");
			String description= request.getParameter("description");
			 
			cite.setCode_cite(code);
			cite.setNom(nom);
			cite.setPays(pays);
			cite.setVille(ville);
			cite.setStatut(true);
			cite.setDescription(description);
			 
			adminEJB.ajoutCite(cite);
			 
			VUE= "/administrateur.jsp";
			
		}
		
		
		
		
		/**************************************Gestion des ajouts d'actualités*****************/
		if(action.equals("ajoutActu")) {
			
			Administrateur admin= null;
			String etatActu= "";
			Actualite actu= new Actualite();
			
			String titre= request.getParameter("titre");
			String description= request.getParameter("description");
			
			actu.setTitre(titre);
			actu.setContenu(description);
			
			adminEJB.ajoutActualite(actu, (Administrateur)request.getSession().getAttribute("admin"));
			 
			VUE= "/administrateur.jsp";
		}
		
		

		
		/*************************************Gestion des notes*******************************/
		if(action.equals("ajoutNote")) {
			
			Etudiant etud= null;
			String etatNote= "";
			Note not= new Note();
			
			String mat= request.getParameter("mat");
			String code= request.getParameter("code");
			String intitule= request.getParameter("intitule");
			double noteCC= Double.parseDouble(request.getParameter("noteCC"));
			double noteNormal= Double.parseDouble(request.getParameter("noteNormale"));
			double noteFinal= Double.parseDouble(request.getParameter("noteFinale"));
			double noteRattrapage= Double.parseDouble(request.getParameter("noteRattrapage"));
			String decision= request.getParameter("decision");
			
			not.setCodeCours(code);
			not.setIntituleCours(intitule);
			not.setNoteCC(noteCC);
			not.setNoteNormale(noteNormal);
			not.setNoteFinale(noteFinal);
			not.setNoteRattrapage(noteRattrapage);
			not.setDecision(decision);
			
			etud= etudiantEJB.consulterProfilEtudiant(mat);
			
			adminEJB.ajoutNote(not, etud); 
			
			VUE= "/administrateur.jsp";
		}
		
		
		
		
		/************************Gestion des emplois du temps***********************/
		if(action.equals("ajoutEmploi")) {
			
			Administrateur admin= null;
			String etatEmploi= "";
			EmploiTemps emploi= new EmploiTemps();
			
			
			String fil= request.getParameter("fil");
			String niv= request.getParameter("niv");
			String code= request.getParameter("code");
			String intitule= request.getParameter("intitule");
			String dateEmploi= request.getParameter("dateEmploi");
			String heureEmploi= request.getParameter("heureEmploi");
			String description= request.getParameter("description");
			
			emploi.setFiliere(fil);
			emploi.setNiveau(niv);
			emploi.setCodeCours(code);
			emploi.setintituleCours(intitule);
			emploi.setDate(dateEmploi);
			emploi.setHeure(heureEmploi);
			emploi.setDescription(description);
			
			adminEJB.ajoutEmploiTemps(emploi, (Administrateur)request.getSession().getAttribute("admin"));
			
			VUE= "/administrateur.jsp";
		}
		
		
		
		
		
		
		this.getServletContext().getRequestDispatcher(VUE).forward( request, response );
		
	}

}
