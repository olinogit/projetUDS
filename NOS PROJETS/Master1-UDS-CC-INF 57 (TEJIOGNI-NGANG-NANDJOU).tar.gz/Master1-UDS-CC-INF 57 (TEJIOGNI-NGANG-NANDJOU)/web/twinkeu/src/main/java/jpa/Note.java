package jpa;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class Note{

	/**
	 * Mapping objet relationnel de la classe Note
	 */
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id_note;
	private String codeCours;
	private String intituleCours;
	
	@Column(nullable=true)
	private double noteCC;
	
	@Column(nullable=true)
	private double noteNormale;
	
	@Column(nullable=true)
	private double noteFinale;
	
	@Column(nullable=true)
	private double noteRattrapage;
	
	private String decision;

	
	@OneToOne
	@JoinColumn(name="matricule_fk", nullable=false)
	private Etudiant etudiant;
	
	

	//	Génération des constructeurs
	public Note(String codeCours, String intituleCours,
			double noteCC, double noteNormale, double noteFinale,
			double noteRattrapage, String decision) {
		this.codeCours = codeCours;
		this.intituleCours = intituleCours;
		this.noteCC = noteCC;
		this.noteNormale = noteNormale;
		this.noteFinale = noteFinale;
		this.noteRattrapage = noteRattrapage;
		this.decision = decision;
	}


	

	public Note() {}


	//	Génération des accesseurs
	public long getId_note() {
		return id_note;
	}


	public void setId_note(long id_note) {
		this.id_note = id_note;
	}


	public String getCodeCours() {
		return codeCours;
	}


	public void setCodeCours(String codeCours) {
		this.codeCours = codeCours;
	}


	public String getIntituleCours() {
		return intituleCours;
	}


	public void setIntituleCours(String intituleCours) {
		this.intituleCours = intituleCours;
	}


	public double getNoteCC() {
		return noteCC;
	}


	public void setNoteCC(double noteCC) {
		this.noteCC = noteCC;
	}


	public double getNoteNormale() {
		return noteNormale;
	}


	public void setNoteNormale(double noteNormale) {
		this.noteNormale = noteNormale;
	}


	public double getNoteFinale() {
		return noteFinale;
	}


	public void setNoteFinale(double noteFinale) {
		this.noteFinale = noteFinale;
	}


	public double getNoteRattrapage() {
		return noteRattrapage;
	}


	public void setNoteRattrapage(double noteRattrapage) {
		this.noteRattrapage = noteRattrapage;
	}


	public String getDecision() {
		return decision;
	}


	public void setDecision(String decision) {
		this.decision = decision;
	}
	
	public Etudiant getEtudiant() {
		return etudiant;
	}


	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}


}