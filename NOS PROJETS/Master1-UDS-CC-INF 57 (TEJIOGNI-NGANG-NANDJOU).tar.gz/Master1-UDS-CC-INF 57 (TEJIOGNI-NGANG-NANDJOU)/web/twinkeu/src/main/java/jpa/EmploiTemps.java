package jpa;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;


@Entity
public class EmploiTemps{

	
	/**
	 * Mapping objet relationnel de la classe EmploiTemps
	 */
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id_empTemps;
	private String niveau;
	private String filiere;
	private String codeCours;
	private String intituleCours;
	private String date;
	private String heure;
	private String description;

	
	@OneToOne
	@JoinColumn(name="id_admin_fk", nullable=false)
	private Administrateur administrateur;
	
	
	
	
	
	
	
	
	
	public String getIntituleCours() {
		return intituleCours;
	}

	public void setIntituleCours(String intituleCours) {
		this.intituleCours = intituleCours;
	}

	public Administrateur getAdministrateur() {
		return administrateur;
	}

	public void setAdministrateur(Administrateur administrateur) {
		this.administrateur = administrateur;
	}

	//	Génération des constructeurs
	public EmploiTemps(String niveau, String filiere,
			String codeCours, String longituleCours, String date, String heure,
			String description) {
		this.niveau = niveau;
		this.filiere = filiere;
		this.codeCours = codeCours;
		this.intituleCours = longituleCours;
		this.date = date;
		this.heure = heure;
		this.description = description;
	}

	public EmploiTemps() {}

	
//	Génération des accesseurs
	public long getId_empTemps() {
		return id_empTemps;
	}

	public void setId_empTemps(long id_empTemps) {
		this.id_empTemps = id_empTemps;
	}

	public String getNiveau() {
		return niveau;
	}

	public void setNiveau(String niveau) {
		this.niveau = niveau;
	}

	public String getFiliere() {
		return filiere;
	}

	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}

	public String getCodeCours() {
		return codeCours;
	}

	public void setCodeCours(String codeCours) {
		this.codeCours = codeCours;
	}

	public String getintituleCours() {
		return intituleCours;
	}

	public void setintituleCours(String intituleCours) {
		this.intituleCours = intituleCours;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getHeure() {
		return heure;
	}

	public void setHeure(String heure) {
		this.heure = heure;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}


}