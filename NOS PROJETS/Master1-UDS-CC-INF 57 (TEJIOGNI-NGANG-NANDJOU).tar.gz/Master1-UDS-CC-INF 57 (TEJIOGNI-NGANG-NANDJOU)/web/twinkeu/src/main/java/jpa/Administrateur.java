package jpa;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Administrateur{


	/**
	 * Mapping objet relationnel de la classe Administrateur
	 */
	
	@Id
	private String login;
	private String password;
	
	
	
	
	
	
	
	
	
	
//	Génération des constructeurs
	public Administrateur(String login, String password) {
		this.login = login;
		this.password = password;
	}


	public Administrateur() {}


//	Génération des accesseurs
	
	public String getLogin() {
		return login;
	}


	public void setLogin(String login) {
		this.login = login;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
	
}