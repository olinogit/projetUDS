package ejb;

import java.util.List;

import javax.ejb.Local;

import jpa.Actualite;
import jpa.Alerte;
import jpa.EmploiTemps;
import jpa.Etudiant;
import jpa.Note;

@Local
public interface EtudiantLocal{
	
//	Gestion du profil
	public void creerProfilEtudiant(Etudiant etudiant);
	public void supprimerProfilEtudiant(Etudiant etudiant);
	public void modifierProfilEtudiant(Etudiant etudiant);
	public Etudiant consulterProfilEtudiant(String matricule);
	
//	Gestion de l'emploi de temps côté etudiant
	public List<EmploiTemps> consulterEmploiTemps(String code_cours);
	
//	Gestion de note côté etudiant
	public List<Note> consulterNote(String matricule);
	
//	Gestion de l'actualite côté etudiant
	public List<Actualite> consulterActualite(String motCle);
	
//	Gestion de l'alerte côté etudiant
	public void envoyerAlerte(Alerte alerte);
	
	
}