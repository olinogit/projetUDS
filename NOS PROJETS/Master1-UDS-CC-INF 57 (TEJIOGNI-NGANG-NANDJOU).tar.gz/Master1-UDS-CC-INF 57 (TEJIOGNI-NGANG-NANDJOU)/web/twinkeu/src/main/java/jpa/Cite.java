package jpa;


import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Lob;


@Entity
public class Cite{

	/**
	 * Mapping objet/relationnel de la classe Cite
	 */
	@Id
	private long code_cite;
	private String nom;
	private String pays;
	private String ville;
	
	@Lob
	@Basic (fetch=FetchType.LAZY)
	private byte[] photo;
	private String description;
	private boolean statut;
	
	
	
	
	
	
	
	

	//	Génération des constructeurs
	public Cite(long code_cite, String nom, String pays, String ville,
			byte[] photo, String description, boolean statut) {
		this.code_cite = code_cite;
		this.nom = nom;
		this.pays = pays;
		this.ville = ville;
		this.photo = photo;
		this.description = description;
		this.statut = statut;
	}


	public Cite() {
		super();
	}


	
//	Génération des accesseurs
	
	public long getCode_cite() {
		return code_cite;
	}


	public void setCode_cite(long code_cite) {
		this.code_cite = code_cite;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getPays() {
		return pays;
	}


	public void setPays(String pays) {
		this.pays = pays;
	}


	public String getVille() {
		return ville;
	}


	public void setVille(String ville) {
		this.ville = ville;
	}


	public byte[] getPhoto() {
		return photo;
	}


	public void setPhoto(byte[] photo) {
		this.photo = photo;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public boolean isStatut() {
		return statut;
	}


	public void setStatut(boolean statut) {
		this.statut = statut;
	}


}