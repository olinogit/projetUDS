package beans;

import java.util.List;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Cite;
import jpa.Etudiant;
import jpa.Note;

public class JSON {
	public JSON(){}
	
	public String etudiantToJson(Etudiant e){
		String etdjson = "{";
					if(e.getNom() != null){
						etdjson +="\"nom\" : \"" +e.getNom()+"\",";
					}
					
					if(e.getPrenom() != null){
						etdjson +="\"prenom\" : \"" +e.getPrenom()+"\",";
					}
			   		
					if(e.getSexe() != null){
						etdjson +="\"sexe\" : \"" +e.getSexe()+"\",";
					}
			   		
					if(e.getMail() != null){
						etdjson +="\"mail\" : \"" +e.getMail()+"\",";
					}
			   		
			   		if(e.getMatricule() != null){
			   			etdjson +="\"matricule\" : \"" +e.getMatricule()+"\",";
					}
			   		
			   		if(e.getFiliere() != null){
			   			etdjson +="\"filiere\" : \"" +e.getFiliere()+"\",";
					}
			   		
			   		if(e.getCni() != 0){
			   			etdjson +="\"cni\" : \"" +e.getCni()+"\",";
					}
			   		
			   		if(e.getDescription() != null){
			   			etdjson +="\"desc\" : \"" +e.getDescription()+"\",";
					}
			   		
			   		if(e.getLieu_naissance() != null){
			   			etdjson +="\"lieu\" : \"" +e.getLieu_naissance()+"\",";
					}
			   		
			   		if(e.getLogin() != null){
			   			etdjson +="\"login\" : \"" +e.getLogin()+"\",";
					}
			   		
			   		if(e.getSexe() != null){
						etdjson +="\"sexe\" : \"" +e.getSexe()+"\",";
					}
			   		etdjson +="\"niv\" : \"" +e.getNiveau()+"\",";
			   		if(e.getPassword() != null){
			   			etdjson +="\"passwd\" : \"" +e.getPassword()+"\",";
					}
			   		
			   		if(e.getPays() != null){
			   			etdjson +="\"pays\" : \"" +e.getPays()+"\",";
					}
			   		
			   		if(e.getQuartier() != null){
			   			etdjson +="\"quartier\" : \"" +e.getQuartier()+"\",";
					}
			   		
			   		if(e.getTelephone() != 0){
			   			etdjson +="\"tel\" : \"" +e.getTelephone()+"\",";
					}
			   		
			   		if(e.getVille() != null){
			   			etdjson +="\"ville\" : \"" +e.getVille()+"\",";
					}
			   		
			   		if(e.getCite() != null){
			   			etdjson +="\"cite\" : \"" +e.getCite()+"\",";
					}
			   		
			   		if(e.getDate_naissance() != null){
			   			etdjson +="\"date\" : \"" +e.getDate_naissance().toString()+"\",";
					}
			   		
			   		if(e.getPhoto() != null){
			   			etdjson +="\"photo\" : \"" +e.getPhoto().toString()+"\",";
					}
			   		
			   		if(e.isStatut()){
			   			etdjson +="\"statut\" : \"" +e.isStatut()+"\"";
					}
			   		
			   		
			   etdjson +="}";
		return etdjson;
	}
	
	
	public String actualiteToJson(Actualite e){
		String etdjson = "{";
			   		etdjson +="\"id\" : \"" +e.getId_actualite()+"\",";
			   		etdjson +="\"titre\" : \"" +e.getTitre()+"\",";
			   		etdjson +="\"content\" : \"" +e.getContenu()+"\",";
			   		etdjson +="\"photo\" : \"" +e.getPhoto().toString()+"\"";
			   etdjson +="}";
		return etdjson;
	}
	
	public String actualiteToJson(List <Actualite> e){
		String etdjson = "[";
		for(int i=0;i<e.size();i++){
					etdjson += "{";
			   		etdjson +="\"id\" : \"" +e.get(i).getId_actualite()+"\",";
			   		etdjson +="\"titre\" : \"" +e.get(i).getTitre()+"\",";
			   		etdjson +="\"content\" : \"" +e.get(i).getContenu()+"\"";
			   		if(e.get(i).getPhoto() != null){
			   			etdjson +="\",photo\" : \"" +e.get(i).getPhoto().toString()+"\"";
					}
			   		etdjson +="},";
		}
			   etdjson +="]";
		return etdjson;
	}
	
	public String citeToJson(List<Cite> e){
		String etdjson = "[";
		for(int i=0;i<e.size();i++){
					etdjson += "{";
			   		etdjson +="\"code\" : \"" +e.get(i).getCode_cite()+"\",";
			   		etdjson +="\"desc\" : \"" +e.get(i).getDescription()+"\",";
			   		etdjson +="\"nom\" : \"" +e.get(i).getNom()+"\",";
			   		etdjson +="\"pays\" : \"" +e.get(i).getPays()+"\",";
			   		etdjson +="\"ville\" : \"" +e.get(i).getVille()+"\"";
			   		if(e.get(i).getPhoto() != null){
			   			etdjson +="\",photo\" : \"" +e.get(i).getPhoto().toString()+"\"";
					}
			   		etdjson +="},";
		}
			   etdjson +="]";
		return etdjson;
	}
	
	
	public String noteToJson(List <Note> e){
		String etdjson = "[";
		for(int i=0;i<e.size();i++){
					etdjson += "{";
			   		etdjson +="\"id\" : \"" +e.get(i).getId_note()+"\",";
			   		etdjson +="\"desc\" : \"" +e.get(i).getDecision()+"\",";
			   		etdjson +="\"code\" : \"" +e.get(i).getCodeCours()+"\",";
			   		etdjson +="\"inti\" : \"" +e.get(i).getIntituleCours()+"\",";
			   		etdjson +="\"cc\" : \"" +e.get(i).getNoteCC()+"\",";
			   		etdjson +="\"normale\" : \"" +e.get(i).getNoteNormale()+"\",";
			   		etdjson +="\"final\" : \"" +e.get(i).getNoteFinale()+"\",";
			   		etdjson +="\"rat\" : \"" +e.get(i).getNoteRattrapage()+"\"";
			   		etdjson +="},";
		}
			   etdjson +="]";
		return etdjson;
	}
	
	
	public String adminToJson(Administrateur e){
		String etdjson = "{";
			   		etdjson +="\"nom\" : \"" +e.getLogin()+"\",";
			   		etdjson +="\"passwd\" : \"" +e.getPassword()+"\"";
			   etdjson +="}";
		return etdjson;
	}
	
	
	
	
	public String toJson(Object o){
		String json = "";
			
			if(o instanceof Etudiant){
				json = this.etudiantToJson((Etudiant)o);
			}else if(o instanceof Administrateur){
				json = this.adminToJson((Administrateur)o);
			}else if(o instanceof Actualite){
				json = this.actualiteToJson((Actualite)o);
			}
			
		return json;
	}
}