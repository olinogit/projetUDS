package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.Administrateur;
import jpa.Cite;
import jpa.Etudiant;
import beans.JSON;
import ejb.AdminEJB;
import ejb.EtudiantEJB;

/**
 * Servlet implementation class servletConnection
 */
public class ConnexionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	AdminEJB adminEJB;
	@EJB
	EtudiantEJB etudiantEJB;
	
    
    //Constructeur par défaut
    public ConnexionServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String actionReload= request.getParameter("action");
		response.setContentType("application/json");
		response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
				PrintWriter out = response.getWriter();
				if(actionReload.equals("reload")) {
					List<Cite> listeCite= adminEJB.listeCite();
					JSON json= new JSON();
					String res = json.citeToJson(listeCite);
					res=res.substring(0,res.length()-2);
					res+="]";
					out.println(res);		
				}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String etatConnexion= "";
	    String VUE= "";
	    
		PrintWriter out = response.getWriter();
		
		Administrateur admin= null;
		Etudiant etudiant= null;
		
		String loginConnexion= request.getParameter("loginConnexion");
		String passConnexion= request.getParameter("passConnexion");
		
		admin= adminEJB.connexionAdmin(loginConnexion, passConnexion);
		//etudiant= etudiantEJB.connexionEtudiant(loginConnexion, passConnexion);
		
		
		
		if(admin != null) {
			request.getSession().setAttribute("admin", admin);
			request.getSession().setAttribute("listeEmploi", adminEJB.listeEmploiTemps());
			request.getSession().setAttribute("listeNote", adminEJB.listeNotes());
			request.getSession().setAttribute("listeCite", adminEJB.listeCite());
			request.getSession().setAttribute("listeActu", adminEJB.listeActualite());
			request.getSession().setAttribute("listeEtud", adminEJB.listeEtudiant());
			
			VUE= "/administrateur.jsp"; 
		}
		else {
			
			etudiant= etudiantEJB.connexionEtudiant(loginConnexion, passConnexion);
			
			if(etudiant != null) {
				request.getSession().setAttribute("etudiant", etudiant);
				request.getSession().setAttribute("listeEmploi_Etudiant", etudiantEJB.listeEmploiTemps(etudiant.getNiveau()));
				request.getSession().setAttribute("listeNote_Etudiant", etudiantEJB.consulterNote(etudiant.getMatricule()));
				request.getSession().setAttribute("listeCite_Etud", adminEJB.listeCite());
				
				
				VUE= "/etudiant.jsp";
			}
			else {
				etatConnexion= "Erreur de connexion, \n"+
							"mot de passe ou login invalide";
				
				VUE= "/index.jsp";
			}
		}
		
		
		
		
		request.setAttribute("etatConnexion", etatConnexion);
		request.setAttribute("loginConnexion", loginConnexion);
		request.setAttribute("passConnexion", passConnexion);
		
		out.println("<h1>"+VUE+"</h1>");
		this.getServletContext().getRequestDispatcher(VUE).forward( request, response );

	}

}
