package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.Cite;
import jpa.Etudiant;
import ejb.AdminEJB;
import ejb.EtudiantEJB;

/**
 * Servlet implementation class ModificationServlet
 */
public class ModificationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	@EJB
	AdminEJB adminEJB;
	@EJB
	EtudiantEJB etudiantEJB;
	
	
    public ModificationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String VUE= "";
	    String action= "";
	    
		PrintWriter out = response.getWriter();
		
		action= request.getParameter("action");
		
		
		
		/**********Gestion de modification du profil etudiant**********/
		if(action.equals("modifProfil_Etudiant")) {
			
			Etudiant etudiant= new Etudiant();
			Cite cite= new Cite();
			
			String nom= request.getParameter("nom");
			String prenom= request.getParameter("prenom");
			String sexe= request.getParameter("sexe");
			String dateNaiss= request.getParameter("dateNaiss");
			String lieuNaiss= request.getParameter("lieuNaiss");
			String fil= request.getParameter("fil");
			String niv= request.getParameter("niv");
			String mat= request.getParameter("mat");
			long cni= Integer.parseInt(request.getParameter("cni"));
			String loginModif= request.getParameter("loginModif");
			String passModif= request.getParameter("passModif");
			String pays= request.getParameter("pays");
			String ville= request.getParameter("ville");
			String quartier= request.getParameter("quartier");
			long telephone= Integer.parseInt(request.getParameter("telephone"));
			String boitemail= request.getParameter("boitemail");
			
			
			String nomCite= request.getParameter("cite");
			
			cite= adminEJB.rechercherCite(nomCite);
			
			
			String description= request.getParameter("description");
			
			
			
			etudiant.setNom(nom);
			etudiant.setPrenom(prenom);
			etudiant.setSexe(sexe);
			etudiant.setDate_naissance(dateNaiss);
			etudiant.setLieu_naissance(lieuNaiss);
			etudiant.setFiliere(fil);
			etudiant.setNiveau(niv);
			etudiant.setMatricule(mat);
			etudiant.setCni(cni);
			etudiant.setLogin(loginModif);
			etudiant.setPassword(passModif);
			etudiant.setPays(pays);
			etudiant.setVille(ville);
			etudiant.setQuartier(quartier);
			etudiant.setTelephone(telephone);
			etudiant.setMail(boitemail);
			//etudiant.setCite(cite);   
			etudiant.setEtat(true);
			etudiant.setStatut(true);
			etudiant.setDescription(description);
			
			Etudiant etud= etudiantEJB.rechercherEtudiant(mat);
			
			etudiantEJB.modifierProfilEtudiant(etud, etudiant);
			
			VUE= "/etudiant.jsp";
		}
		
		
		
		
		this.getServletContext().getRequestDispatcher(VUE).forward( request, response );
	}

}
