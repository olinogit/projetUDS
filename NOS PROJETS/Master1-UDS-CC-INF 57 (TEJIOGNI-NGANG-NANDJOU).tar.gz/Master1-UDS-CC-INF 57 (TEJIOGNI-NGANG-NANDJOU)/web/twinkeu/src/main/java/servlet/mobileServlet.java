package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.Actualite;
import jpa.Administrateur;
import jpa.Etudiant;
import jpa.Note;
import beans.JSON;
import ejb.AdminEJB;
import ejb.EtudiantEJB;

/**
 * Servlet implementation class mobileServlet
 */
@WebServlet("/mobileServlet")
public class mobileServlet extends HttpServlet {
	@EJB
	AdminEJB admins;
	@EJB
	EtudiantEJB etds;
	
	private static final long serialVersionUID = 1L;
    private JSON json = new JSON();
    /**
     * @see HttpServlet#HttpServlet()
     */
    public mobileServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();	
		response.setContentType("application/json");
		response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
		String res="";
		
		if(request.getParameter("action").equals("connexion")){
			String login = request.getParameter("login");
			String passwd = request.getParameter("passwd");
			
			Administrateur ad = admins.connexionAdmin(login, passwd);
			Etudiant etd = etds.connexionEtudiant(login, passwd);
			
			
			
			if(ad == null ){
				if(etd == null){
					res=null;
				}else{
					res=json.toJson(etd);
				}
			}else{
				res=json.toJson(ad);
			}
			
			out.println(res);
		}
		else if (request.getParameter("action").equals("listeActu")){
			
			List<Actualite> listActu = etds.listeActualite();
			res = json.actualiteToJson(listActu);
			res=res.substring(0,res.length()-2);
			res+="]";
			out.println(res);
		}
		else if (request.getParameter("action").equals("note")){
					String matricule = request.getParameter("mat");
					List<Note> listeNote = etds.consulterNote(matricule);
					res = json.noteToJson(listeNote);
					res=res.substring(0,res.length()-2);
					res+="]";
					out.println(res);
				}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();	
		out.println("je suis dans do post ");
	}

}