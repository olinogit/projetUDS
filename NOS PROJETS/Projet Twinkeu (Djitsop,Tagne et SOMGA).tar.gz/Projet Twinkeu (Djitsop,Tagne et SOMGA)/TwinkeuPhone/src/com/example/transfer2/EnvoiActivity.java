﻿package com.example.transfer2;


import android.app.Activity;

import android.content.Intent;

import android.os.Bundle;

import android.view.View;

import android.view.View.OnClickListener;

import android.widget.Button;

 
public class EnvoiActivity extends Activity {
	

	  Button suiv = null;
	  
public final static String AGE = "sdz.chapitreTrois.intent.example.AGE";

	  Intent secondeActivite=null;
	
	
  
 
 public void onCreate(Bundle savedInstanceState) {
 super.onCreate(savedInstanceState);   
 setContentView(R.layout.activity_envoi);   
 suiv = (Button)findViewById(R.id.suivant);  
  suiv.setOnClickListener(envoyerListener);      
  // On récupère l'intent qui a lancé cette activité 
 }
  // Uniquement pour le bouton "envoyer" 
 private OnClickListener envoyerListener = new OnClickListener() {   
// @Override  
 public void onClick(View v) {      
 // Le premier paramètre est le nom de l'activité actuelle     
  // Le second est le nom de l'activité de destination        
secondeActivite = new Intent(EnvoiActivity.this, Envoi2Activity.class);  
        // On rajoute un extra
       
 secondeActivite.putExtra(AGE, 31);        
// Puis on lance l'intent !       
 startActivity(secondeActivite);  
   }   
 };
}
 