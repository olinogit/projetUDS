package com.example.transfer2;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnKeyListener;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
 
public class MainActivity extends Activity {
  // La chaîne de caractères par défaut
  private final String defaut = "Vous devez cliquer sur le bouton « Connexion » pour vous connecter.";
  // La chaîne de caractères de la megafonction
  private final String megaString = "connexion en cours !";
  public final static String AGE = "sdz.chapitreTrois.intent.example.AGE";
  Intent secondeActivite=null;
  
  Button envoyer = null;
  Button raz = null;
     
  EditText poids = null;
  EditText taille = null;
     
  RadioGroup group = null;
     
  TextView result = null;
     
  CheckBox mega = null;
     
  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_connexion);
         
    // On récupère toutes les vues dont on a besoin
    envoyer = (Button)findViewById(R.id.connect);
         
    raz = (Button)findViewById(R.id.raz);
         
    taille = (EditText)findViewById(R.id.motdepasse);
    poids = (EditText)findViewById(R.id.ident);
         
    mega = (CheckBox)findViewById(R.id.mega);
         
    group = (RadioGroup)findViewById(R.id.group);
 
    result = (TextView)findViewById(R.id.result);
 
    // On attribue un listener adapté aux vues qui en ont besoin
    envoyer.setOnClickListener(envoyerListener);
    raz.setOnClickListener(razListener);
    taille.addTextChangedListener(textWatcher);
    poids.addTextChangedListener(textWatcher);
 
    // Solution avec des onKey
    //taille.setOnKeyListener(modificationListener);
    //poids.setOnKeyListener(modificationListener);
    mega.setOnClickListener(checkedListener);
  }
 
  
  // Se lance à chaque fois qu'on appuie sur une touche en étant sur un EditText
  private OnKeyListener modificationListener = new OnKeyListener() {
    public boolean onKey(View v, int keyCode, KeyEvent event) {
      // On remet le texte à sa valeur par défaut pour ne pas avoir de résultat incohérent
      result.setText(defaut);
      return false;
    }

	public boolean onKey(DialogInterface arg0, int arg1, KeyEvent arg2) {
		// TODO Auto-generated method stub
		return false;
	}
  };
 
  private TextWatcher textWatcher = new TextWatcher() {
 
    //@Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
      result.setText(defaut);
    }
         
   // @Override
    public void beforeTextChanged(CharSequence s, int start, int count,
      int after) {
   
    }
   
  //  @Override
    public void afterTextChanged(Editable s) {
   
    }
  };
     
  // Uniquement pour le bouton "envoyer"
  private OnClickListener envoyerListener = new OnClickListener() {
   // @Override
    public void onClick(View v) {
        // Le premier paramètre est le nom de l'activité actuelle
        // Le second est le nom de l'activité de destination
         secondeActivite = new Intent(MainActivity.this, MenuActivity.class);
         
        // On rajoute un extra
        secondeActivite.putExtra(AGE, 31);
 
        // Puis on lance l'intent !
        startActivity(secondeActivite);
      }
    
  };
     
  // Listener du bouton de remise à zéro
  private OnClickListener razListener = new OnClickListener() {
   // @Override
    public void onClick(View v) {
      poids.getText().clear();
      taille.getText().clear();
      result.setText(defaut);
    }
  };
     
  // Listener du bouton de la megafonction.
  private OnClickListener checkedListener = new OnClickListener() {
    //@Override
    public void onClick(View v) {
      // On remet le texte par défaut si c'était le texte de la megafonction qui était écrit
      if(!((CheckBox)v).isChecked() && result.getText().equals(megaString))
        result.setText(defaut);
    }
  };
}