package com.example.transfer2;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;

public class Envoi2Activity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_envoi2);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_envoi2, menu);
        return true;
    }
}
