package servlet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




/**
 * Servlet implementation class Test
 */
@WebServlet("/Action")
public class Action extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	Etudiantd etudEBJ;

	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		requete(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		requete(request, response);
	}

	protected void requete(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ServletOutputStream out = response.getOutputStream();
		
		out.println("INFORMATIONS SUR L'ETUDIANT:");
		
		String action = "";
				
		action = request.getParameter("action");
		
		if(action == "saveEtudiant"){
			String matricule = request.getParameter("matricule");
			String nom = request.getParameter("nom");
			String prenom = request.getParameter("prenom");
			String age = request.getParameter("age");
			String sexe = request.getParameter("sexe");
			String filiere = request.getParameter("filiere");
			String niveau = request.getParameter("niveau");
			String numero = request.getParameter("numero");
			String numeroc = request.getParameter("numeroc");
			String nomc = request.getParameter("nomc");
			String adressec = request.getParameter("adressec");
			
			out.println(" Matricule= "+matricule);
			out.println(" Nom= "+nom);
			out.println(" Prenom= "+prenom);
			out.println(" Age= "+age);
			out.println(" votre sexe= "+sexe);
			out.println(" Filiere= "+filiere);
			out.println(" niveau= "+niveau);
			out.println(" Numero De Telephone= "+numero);

			out.println(" nom de la cité= "+nomc);
			out.println(" Numero Du Concierge= "+numeroc);
			out.println("L'adresse de la cité est:"+adressec);
			

		}
		
		
		
	}

}
