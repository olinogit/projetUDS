package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jpa.CiteU;
import jpa.Etudiant;

@Stateless
public class CiteUd {
@PersistenceContext
EntityManager ec;
	public void saveCity(CiteU c) {
		ec.persist(c);
}
	
	public List listerOfCity() {
		List list = null;
		return list;
	}
	public Etudiant findCity(int id) {
		Etudiant c = null;
		return c;
	}
	public void removeCity(CiteU c) {
		ec.remove(c);
	}
	
	//met à jour un etudiant 
		public void refreshCity(CiteU c) {
			ec.refresh(c);
		}
}
