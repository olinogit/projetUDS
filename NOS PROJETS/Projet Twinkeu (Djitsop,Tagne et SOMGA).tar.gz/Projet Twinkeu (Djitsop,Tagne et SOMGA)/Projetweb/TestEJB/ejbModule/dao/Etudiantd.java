package dao;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import jpa.Etudiant;

@Stateless
public class Etudiantd {
	@PersistenceContext
	EntityManager em;
	// enregistre un etudiant dans la BD
	public void save(Etudiant e){
		em.persist(e);
	}
	// lister les etudiants de la BD
	public List<Etudiant> getAllEtudiant(){
		return em.createQuery("select e from etudiant e").getResultList();
		}
	//recherche un etudiant avec son matricule dans la BD
	public Etudiant getEtudiantByMat(long mat){
		return em.find(mat).getSingleResult();
		}
	//supprimme un etudiant de la BD
	public void removeEtudiant(Etudiant e) {
		em.remove(e);
	}
	//met à jour un etudiant 
	public void refreshEtudiant(Etudiant e) {
		em.refresh(e);
	}
	//recherche un etudiant à partir de son nom
	public Etudiant getEtudiantByName(String name){
		Query query = new Query("select e from etudiant e where "
				+ "query.setParameter("name", name);
		return em.createQuery(query).getSingleResult();
		}	

}
