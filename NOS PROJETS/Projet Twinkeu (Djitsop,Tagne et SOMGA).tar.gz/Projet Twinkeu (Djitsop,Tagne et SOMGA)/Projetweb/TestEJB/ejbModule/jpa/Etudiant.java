package jpa;

import javax.persistence.*;
import javax.persistence.*;

@Entity // ceci permet de creer la table étudiant
public class Etudiant {
	@Id 
	 String Matricule;
	 String nom;
	 String prenom;
	 int age;
	 int filiere;
	 long numero;
	@ManyToOne
	CiteU citeU;
}
