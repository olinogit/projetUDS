package jpa;


import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class CiteU {
@Id
int id;// (strategy = GeneratedTYPE.AUTO);
@OneToMany (fetch = FetchType.LAZY)
List <Etudiant> etudiants;
String nom;
String adresse;
long numeroc;
}
