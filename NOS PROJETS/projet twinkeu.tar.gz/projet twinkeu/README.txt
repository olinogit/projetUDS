nous avons joint ici le point war: twinkeu.war
une page de couverture ou il ya le nom des participant aux projet
un rapport parlant du projet
un document presentant les diagrammes de cas dutilisation 

pour la base de donnes sous postgres nous avons utilise twinkeu
lorsqu on demare postgres  le mot de passe utilise est: admin

pour notre projet il faut dabor creer un administrateur avant de commencer



