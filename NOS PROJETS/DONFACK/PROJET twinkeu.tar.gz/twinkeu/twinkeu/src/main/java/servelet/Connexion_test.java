package servelet;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.CiteU;
import jpa.Etudiant;
import ejb.CiteUDAO;
import ejb.EtudiantDAO;

/**
 * Servlet implementation class Connexion_test
 */
public class Connexion_test extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Connexion_test() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String login=request.getParameter("log");
		String password=request.getParameter("pass");
		
		
		//CiteU cv=cts.rechercheCite(password);
		Etudiant cvt=etud.rechercheEtudiant(password);
		
		try{
			
			if  ((cvt.getNomEtudiant().equals(login))&&(cvt.getMatriculeEtudiant().equals(password))){
				
				this.getServletContext().getRequestDispatcher("/ecrire.jsp").forward(request, response);
			}	
			}catch(Exception e){ 
				
				 if (login.equals("admin")&&(password.equals("admin"))){
					
					
					
					this.getServletContext().getRequestDispatcher("/entrernote.jsp").forward(request, response);
					}
			
				}
				
			try{
		if  ((cvt.getNomEtudiant().equals(login))&&(cvt.getMatriculeEtudiant().equals(password))){
		
				this.getServletContext().getRequestDispatcher("/ecrire.jsp").forward(request, response);
			     
			}
		}catch(Exception e){ 
		
		CiteU cv1=cts.rechercheCite(password);
		 if ((cv1.getAdressecons().equals(login))&&(cv1.getNomCiteU().equals(password))){
			
			
			
			this.getServletContext().getRequestDispatcher("/consierge.jsp").forward(request, response);
			}
	
		} 
		
		
		
		
		
		
	}

}
