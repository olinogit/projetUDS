package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class EnvoiMessage_consierge extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnvoiMessage_consierge() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String no=request.getParameter("typ");//type de message
		String fi=request.getParameter("don");//donnee du message
		
		int ag=Integer.parseInt(request.getParameter("ide"));//identite du message
		String ci=request.getParameter("mat");//nom de la cite 
	
		CiteU cv=cts.rechercheCite(ci);
		
		
		PrintWriter out = response.getWriter();
			
		response.setContentType("text/html");
		 
		 
		if (cv!=null){
		
			Message c=new Message(ag,no,fi,cv);	
			cts.envoi_message(c);
			this.getServletContext().getRequestDispatcher("/consierge.jsp").forward(request, response);
		
		}else{
			out.println("<h1>il n'existe pas</h1>");
		}
		
		
	}

}
