package servelet;

import java.io.IOException;
import java.util.List;

import javax.ejb.EJB;
import javax.persistence.NoResultException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.eclipse.jdt.internal.compiler.ast.BreakStatement;

import ejb.CiteUDAO;
import ejb.EtudiantDAO;
import jpa.CiteU;
import jpa.Etudiant;

/**
 * Servlet implementation class connexion
 */
public class connexion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public connexion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String login=request.getParameter("log");
		String password=request.getParameter("pass");
		
		
		//CiteU cv=cts.rechercheCite(password);
		Etudiant cvt=etud.rechercheEtudiant(password);
		
		try{
			
			if  ((cvt.getNomEtudiant().equals(login))&&(cvt.getMatriculeEtudiant().equals(password))){
				
				this.getServletContext().getRequestDispatcher("/ecrire.jsp").forward(request, response);
			}	
			}catch(Exception e){ 
				
				 if (login.equals("admin")&&(password.equals("admin"))){
					
					
					
					this.getServletContext().getRequestDispatcher("/entrernote.jsp").forward(request, response);
					}
			
				}
				
			try{
		if  ((cvt.getNomEtudiant().equals(login))&&(cvt.getMatriculeEtudiant().equals(password))){
		
				this.getServletContext().getRequestDispatcher("/ecrire.jsp").forward(request, response);
			     
			}
		}catch(Exception e){ 
		
		CiteU cv1=cts.rechercheCite(password);
		 if ((cv1.getAdressecons().equals(login))&&(cv1.getNomCiteU().equals(password))){
			
			
			
			this.getServletContext().getRequestDispatcher("/consierge.jsp").forward(request, response);
			}
	
		} 
		
		
		
		
		
			
		 
		
	
	}
		}


