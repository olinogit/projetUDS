package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class ListeEtudiant_parCiteU extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListeEtudiant_parCiteU() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("cit");//nom de la cite dont on veut lister les etudiants
		
		
		List <Etudiant> cv=etud.listerEtudiant();
	
		PrintWriter out = response.getWriter();
			
      	response.setContentType("text/html");
		 
		for (Etudiant allo:cv){
			
				 String co=allo.getCiteEtudiant().getNomCiteU(); 
				
				if (co.equals(ma)){
					
					request.setAttribute("test", allo.getNomEtudiant());
					
				this.getServletContext().getRequestDispatcher("/affiche.jsp").forward(request, response);
		
				
			}
				
			}
				
	}	

}
