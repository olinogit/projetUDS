package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class RechercheEtudiant extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechercheEtudiant() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("mat");//matricule de l'etudiant dont on veut les renseignements
		
		
		Etudiant cv=etud.rechercheEtudiant(ma);
	
		PrintWriter out = response.getWriter();
			
		response.setContentType("text/html");
		 
		 
		if (cv!=null){
		
			request.setAttribute("test", cv.getNomEtudiant());
			request.setAttribute("tes", cv.getFiliereEtudiant());
			
			CiteU cve=cv.getCiteEtudiant();
			request.setAttribute("citer", cve.getNomCiteU());
		this.getServletContext().getRequestDispatcher("/rechercheEtudiant.jsp").forward(request, response);
				
			

		
		}else{
			
			this.getServletContext().getRequestDispatcher("/rechercheEtudiant.jsp").forward(request, response);
			
		}
		
		
	}

}
