package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import jpa.*;

@Stateless
public class EtudiantDAO {
	
	@PersistenceContext
	EntityManager em;
	Etudiant etud;
	Message messag,mes;
	public void enregister(Etudiant e){
		em.persist(e);
	}
	
	public void envoie_SMS(Message mess){
		
		em.persist(mess);
	}
	
	
	public Etudiant rechercheEtudiant(String matricule){
		
		etud=em.find(Etudiant.class, matricule);
		return etud;
		
		
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Message> lister_messsage(){
		
		Query query=em.createQuery("select e from Message e");
		List etudess =query.getResultList();
		return etudess;
		
		
		    
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Etudiant> listerEtudiant(){
		Query query=em.createQuery("select e from Etudiant e");
		List etudes =query.getResultList();
		return etudes;
		
	}

	

}
