package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.com.sun.corba.se.impl.protocol.giopmsgheaders.KeyAddr;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class ReceptionMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReceptionMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("mat");//matricule de l'etudiant dont on veut lister les messages
		
		
		List <Message> cv=etud.lister_messsage();
	
		PrintWriter out = response.getWriter();
			
      	response.setContentType("text/html");
		
		for ( Message allo:cv){
			if (allo.getRecepetuMessage()!=null){
				 String co=allo.getRecepetuMessage().getMatriculeEtudiant(); 
				
				
				if (co.equals(ma)){
					
					
					
				
					
					request.setAttribute("i", allo.getDonneesMessage());
					 this.getServletContext().getRequestDispatcher("/boitedereception.jsp").forward(request, response);	
					 
					
			
			}
				
			} 
	}

 }
	}
