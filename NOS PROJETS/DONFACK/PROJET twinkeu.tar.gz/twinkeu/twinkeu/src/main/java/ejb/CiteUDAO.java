package ejb;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import jpa.*;

@Stateless

public class CiteUDAO {
	
	@PersistenceContext
	EntityManager em;
	Message messag;
	Etudiant etud;
	CiteU cte;
	
	

		
		public void enregistrer(CiteU cite){
			
			em.persist(cite);
			
		}
		
	public void envoi_message(Message mess){
		em.persist(mess);
		
	}
	
	
	public CiteU rechercheCite(String nomcite){
		
		Query query=em.createQuery("select e from CiteU e where e.nomCiteU=:nomcite");
		query.setParameter("nomcite",nomcite);
		CiteU ctee=  (CiteU) query.getSingleResult();
		
		
			/*cte=em.find(CiteU.class, nomcite);*/
			return ctee;
			
			
		}



}
