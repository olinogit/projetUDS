package jpa;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Message {
	
	@Id
	private int idMessage;
	private String typeMessage;
	private String donneesMessage;
	
	
	public Message() {
		super();
	}
	@ManyToOne
	Etudiant envoietuMessage;
	@ManyToOne
	Etudiant recepetuMessage;
	@ManyToOne
	CiteU envoicons;
	
	
	
	
	
	public Message(int idMessage, String typeMessage, String donneesMessage,
			Etudiant envoietuMessage, Etudiant recepetuMessage) {
		super();
		this.idMessage = idMessage;
		this.typeMessage = typeMessage;
		this.donneesMessage = donneesMessage;
		this.envoietuMessage = envoietuMessage;
		this.recepetuMessage = recepetuMessage;
	}


	public Message(int idMessage, String typeMessage, String donneesMessage,
			Etudiant envoietuMessage) {
		super();
		this.idMessage = idMessage;
		this.typeMessage = typeMessage;
		this.donneesMessage = donneesMessage;
		this.envoietuMessage = envoietuMessage;
	}
	
	
	public Message(int idMessage, String typeMessage, String donneesMessage,CiteU envoicons) {
		super();
		this.idMessage = idMessage;
		this.typeMessage = typeMessage;
		this.donneesMessage = donneesMessage;
		this.envoicons=envoicons;
	}
	
	
	



	public int getIdMessage() {
		return idMessage;
	}
	public void setIdMessage(int idMessage) {
		this.idMessage = idMessage;
	}
	public String getTypeMessage() {
		return typeMessage;
	}
	public void setTypeMessage(String typeMessage) {
		this.typeMessage = typeMessage;
	}
	public String getDonneesMessage() {
		return donneesMessage;
	}
	public void setDonneesMessage(String donneesMessage) {
		this.donneesMessage = donneesMessage;
	}
	public Etudiant getEnvoietuMessage() {
		return envoietuMessage;
	}
	public void setEnvoietuMessage(Etudiant envoietuMessage) {
		this.envoietuMessage = envoietuMessage;
	}


	public Etudiant getRecepetuMessage() {
		return recepetuMessage;
	}


	public void setRecepetuMessage(Etudiant recepetuMessage) {
		this.recepetuMessage = recepetuMessage;
	}
	


	
	
	
}
