package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class EnregistrementEtudiant extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnregistrementEtudiant() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nom=request.getParameter("nom");
		int age=Integer.parseInt(request.getParameter("age"));
		long num=Integer.parseInt(request.getParameter("tel"));
		String fil=request.getParameter("fil");
		long niv=Integer.parseInt(request.getParameter("niv"));
		String mat=request.getParameter("mat");
		String cit=request.getParameter("cit");
	
		CiteU cv=cts.rechercheCite(cit);
		
		
		
	
		PrintWriter out = response.getWriter();
			
		response.setContentType("text/html");
		 
		 
		if (cv!=null){
		
			Etudiant c=new Etudiant(mat,nom,fil,niv,num,age,cv);	
			etud.enregister(c);
			this.getServletContext().getRequestDispatcher("/test.jsp").forward(request, response);
		
		}else{
			out.println("<h1>il n'existe pas</h1>");
		}
		
		
	}

}
