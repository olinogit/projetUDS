package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class EnvoiEmploi_temps extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnvoiEmploi_temps() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("emp");//donnee du message
		
		String fi=request.getParameter("fil");//filiere
		long ni=Integer.parseInt(request.getParameter("niv"));// niveau
		
		int ag=Integer.parseInt(request.getParameter("ide"));//identite du message
		
		
		
		
		List <Etudiant> cv=etud.listerEtudiant();
	
		PrintWriter out = response.getWriter();
			
      	response.setContentType("text/html");
		 
		for (Etudiant allo:cv){
			
				 long co=allo.getNiveauEtudiant(); 
				
				
				if (co==ni){
					
					Message mese=new  Message(ag,fi,ma,null,allo);
					etud.envoie_SMS(mese);
		ag++;
		this.getServletContext().getRequestDispatcher("/emploidetemps.jsp").forward(request, response);
		
				
			}
				
			}
	
		
		this.getServletContext().getRequestDispatcher("/index.jsp").forward(request, response);
		
	}

}
