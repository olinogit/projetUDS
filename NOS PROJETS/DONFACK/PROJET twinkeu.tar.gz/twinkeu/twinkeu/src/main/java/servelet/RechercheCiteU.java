package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jpa.*;
import ejb.*;





/**
 * Servlet implementation class enregistrerEtudiant
 */
@WebServlet("/enregistrerEtudiant")
public class RechercheCiteU extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RechercheCiteU() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("ma");
		
		CiteU cv=cts.rechercheCite(ma);
		
	
		PrintWriter out = response.getWriter();
			
      	response.setContentType("text/html");
		 
		
		out.println("<h4>"+cv.getCoordCiteU()+"<h4>");		
			
		
	}

}
