package jpa;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Etudiant {
	
	@Id
	 private String matriculeEtudiant;
	 private String nomEtudiant;
	 private String filiereEtudiant;
	 private long niveauEtudiant;
	 private long numeroEtudiant;
	 private int ageEtudiant;
	@ManyToOne
	CiteU citeEtudiant;
	@OneToMany( fetch=FetchType . LAZY)
	List <Message> envoimessEtudiant;
	@OneToMany( fetch=FetchType . LAZY)
	List <Message> recepmessEtudiant;
   
	
	public Etudiant(){
		super();
	}
	
	
	
	public Etudiant(String matriculeEtudiant, String nomEtudiant,
			String filiereEtudiant, long niveauEtudiant, long numeroEtudiant,
			int ageEtudiant) {
		super();
		this.matriculeEtudiant = matriculeEtudiant;
		this.nomEtudiant = nomEtudiant;
		this.filiereEtudiant = filiereEtudiant;
		this.niveauEtudiant = niveauEtudiant;
		this.numeroEtudiant = numeroEtudiant;
		this.ageEtudiant = ageEtudiant;
	}



	public Etudiant(String matriculeEtudiant, String nomEtudiant,
			String filiereEtudiant, long niveauEtudiant, long numeroEtudiant,int ageEtudiant,
			CiteU citeEtudiant) {
		super();
		this.matriculeEtudiant = matriculeEtudiant;
		this.nomEtudiant = nomEtudiant;
		this.filiereEtudiant = filiereEtudiant;
		this.niveauEtudiant = niveauEtudiant;
		this.numeroEtudiant = numeroEtudiant;
		this.ageEtudiant = ageEtudiant;
		this.citeEtudiant=citeEtudiant;
		
	}



	
	public String getMatriculeEtudiant() {
		return matriculeEtudiant;
	}
	public void setMatriculeEtudiant(String matriculeEtudiant) {
		this.matriculeEtudiant = matriculeEtudiant;
	}
	public String getNomEtudiant() {
		return nomEtudiant;
	}
	public void setNomEtudiant(String nomEtudiant) {
		this.nomEtudiant = nomEtudiant;
	}
	public String getFiliereEtudiant() {
		return filiereEtudiant;
	}
	public void setFiliereEtudiant(String filiereEtudiant) {
		this.filiereEtudiant = filiereEtudiant;
	}
	public long getNiveauEtudiant() {
		return niveauEtudiant;
	}
	public void setNiveauEtudiant(long niveauEtudiant) {
		this.niveauEtudiant = niveauEtudiant;
	}
	public long getNumeroEtudiant() {
		return numeroEtudiant;
	}
	public void setNumeroEtudiant(long numeroEtudiant) {
		this.numeroEtudiant = numeroEtudiant;
	}
	public int getAgeEtudiant() {
		return ageEtudiant;
	}
	public void setAgeEtudiant(int ageEtudiant) {
		this.ageEtudiant = ageEtudiant;
	}



	public CiteU getCiteEtudiant() {
		return citeEtudiant;
	}



	public void setCiteEtudiant(CiteU citeEtudiant) {
		this.citeEtudiant = citeEtudiant;
	}
	
	
	
	
	

}
