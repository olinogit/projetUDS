package jpa;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class CiteU {

	
	
	@Id
	 private String nomCiteU;
	 private String coordCiteU;
	 private String adressecons;
	@OneToMany( fetch=FetchType . LAZY)
	List<Etudiant> listEtudiants;
	@OneToMany( fetch=FetchType . LAZY)
	List <Message> listMessages;
	
	
	
	
	
	public CiteU() {
		super();
	}
	
	public CiteU(String nomCiteU, String coordCiteU, String adressecons) {
		super();
		this.nomCiteU = nomCiteU;
		this.coordCiteU = coordCiteU;
		this.adressecons = adressecons;
	}
	public String getNomCiteU() {
		return nomCiteU;
	}
	public void setNomCiteU(String nomCiteU) {
		this.nomCiteU = nomCiteU;
	}
	public String getCoordCiteU() {
		return coordCiteU;
	}
	public void setCoordCiteU(String coordCiteU) {
		this.coordCiteU = coordCiteU;
	}
	public String getAdressecons() {
		return adressecons;
	}
	public void setAdressecons(String adressecons) {
		this.adressecons = adressecons;
	}

	public List<Etudiant> getListEtudiants() {
		return listEtudiants;
	}

	public void setListEtudiants(List<Etudiant> listEtudiants) {
		this.listEtudiants = listEtudiants;
	}
	
	

	
	
	
}
