package servelet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ejb.CiteUDAO;
import ejb.EtudiantDAO;
import jpa.Etudiant;
import jpa.Message;

/**
 * Servlet implementation class EnvoiNotes
 */
public class EnvoiNotes extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	EtudiantDAO etud;
	@EJB
	CiteUDAO cts;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnvoiNotes() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

	
	@SuppressWarnings("unused")
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String ma=request.getParameter("mat");//matricule de l'etudiant dont on veut entrer les notes
		String no=request.getParameter("don");//donnee du message
		String fi=request.getParameter("typ");//type de message
		
		int ag=Integer.parseInt(request.getParameter("ide"));//identite du message
		
		
		List <Etudiant> cv=etud.listerEtudiant();
	
		PrintWriter out = response.getWriter();
			
      	response.setContentType("text/html");
		
		for (Etudiant allo:cv){
			
				 String co=allo.getMatriculeEtudiant();
				
				
				if (co.equals(ma)){
					
					Message mese=new  Message(ag,fi,no,null,allo);
					etud.envoie_SMS(mese);
					this.getServletContext().getRequestDispatcher("/entrernote.jsp").forward(request, response);
		
				
			}
				
			}
	
	}

}
