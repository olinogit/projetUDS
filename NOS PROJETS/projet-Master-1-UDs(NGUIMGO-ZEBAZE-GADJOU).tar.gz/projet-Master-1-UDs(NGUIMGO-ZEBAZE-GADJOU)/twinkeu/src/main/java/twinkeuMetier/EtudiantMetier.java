package twinkeuMetier;

import java.io.IOException;
import java.sql.Date;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import twinkeuDAO.CiteUDAO;
import twinkeuDAO.EtudiantDAO;
import twinkeuJPA.CiteU;
import twinkeuJPA.Etudiant;

/**
 * Servlet implementation class EtudiantMetier
 */
public class EtudiantMetier extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@EJB
	EtudiantDAO ed;
	
	@EJB
	CiteUDAO cd;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EtudiantMetier() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = request.getParameter("login");
		String passwd = request.getParameter("passwd");
		String nom_user = request.getParameter("nometd");
		String prenom_user = request.getParameter("prenometd");
		String d= request.getParameter("datenaiss");
		int numTel_user = Integer.parseInt(request.getParameter("teletd"));
		String matriculeEtd = request.getParameter("matricule");
		String filiereEtd = request.getParameter("filiere");
		int niveauEtd = Integer.parseInt(request.getParameter("niveau"));
		String nomCite = request.getParameter("nomCite");
		
		CiteU citeu = cd.searchCiteU(nomCite);
		String[] dd=d.split("/");
		int year = Integer.parseInt(dd[0]);
		int month = Integer.parseInt(dd[1]);
		int date = Integer.parseInt(dd[2]);
		@SuppressWarnings("deprecation")
		Date datenaiss = new Date(year, month, date);
		
		Etudiant etud = new Etudiant(login, passwd, nom_user,
				prenom_user, datenaiss, matriculeEtd,
				filiereEtd, niveauEtd, numTel_user, citeu);
		
		ed.addEtudiant(etud);
		
		this.getServletContext().getRequestDispatcher("/enregistrement.jsp" )
		.forward( request, response );
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
