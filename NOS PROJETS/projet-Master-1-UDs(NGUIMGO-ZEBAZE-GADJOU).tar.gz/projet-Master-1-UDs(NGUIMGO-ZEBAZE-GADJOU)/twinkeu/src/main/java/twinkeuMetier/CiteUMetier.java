package twinkeuMetier;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import twinkeuDAO.CiteUDAO;
import twinkeuDAO.UserDAOLocal;
import twinkeuJPA.CiteU;
import twinkeuJPA.Users;

/**
 * Servlet implementation class CiteUMetier
 */
public class CiteUMetier extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@EJB
	CiteUDAO cd;
	
	@EJB
	UserDAOLocal ud;
	
	String result = "echec d'enregistrement";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CiteUMetier() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nomcu = request.getParameter("nomcu");
		String coordoGeo = request.getParameter("coordoGeo");
		long telconcierge = Integer.parseInt(request.getParameter("telconcierge"));
				
		Users concierge = ud.searchByTel(telconcierge);
		if(concierge !=null){
			CiteU cite = new CiteU(nomcu, coordoGeo, concierge);
			cd.addCiteU(cite);
			result = "Votre cite a ete bien enregistree";
		}
		request.setAttribute(result, result);
		this.getServletContext().getRequestDispatcher("/ajoutCite.jsp" )
		.forward( request, response );
	}

}
