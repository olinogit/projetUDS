package twinkeuMetier;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import twinkeuDAO.ConnexionForm;
import twinkeuDAO.MessageDAOLocal;
import twinkeuDAO.UserDAO;
import twinkeuDAO.UserDAOLocal;
import twinkeuJPA.Message;
import twinkeuJPA.UserId;
import twinkeuJPA.Users;

public class Connexion extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public static final String ATT_USER         = "user";
	public static final String ATT_FORM         = "form";
	public static final String ATT_SESSION_USER = "userSession";
	public static final String VUE              = "/connexion.jsp";
	
	@EJB
	UserDAOLocal ud;
	
	@EJB
	MessageDAOLocal md;
	
	public void doGet( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
		
		/* Affichage de la page de connexion */
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}
	
	public void doPost( HttpServletRequest request, HttpServletResponse response ) throws ServletException, IOException {
		
		ConnexionForm form = new ConnexionForm();		
		/* Traitement de la requête et récupération du bean en résultant */
		
		UserId uid = form.getLogin(request);
		
		Users user = null;
		
		user = ud.connecterUsers(uid);
		
		List<Users> listU = new ArrayList<Users>();	
		List<Message> listSms = new ArrayList<Message>();
		
		listU = ud.getAllUsers();
		
		listSms = md.smsByUser(user);
			
		/* Récupération de la session depuis la requête */
		HttpSession session = request.getSession();
		
		/**
		 * Si aucune erreur de validation n'a eu lieu, alors ajout du bean
		 * Utilisateur à la session, sinon suppression du bean de la session.
		 */
		if ( user != null ) {
			
			form.setResultat("Succès de la connexion.");
			//System.out.println(user.getLogin());
			session.setAttribute( ATT_SESSION_USER, user );
		} else {
			
			form.setResultat("Échec de la connexion.");
			
			session.setAttribute( ATT_SESSION_USER, null );
		}		
			
		
		/* Stockage du formulaire et du bean dans l'objet request */
		request.setAttribute( ATT_FORM, form );
		
		request.setAttribute( ATT_USER, user );
		
		session.setAttribute("listU", listU);
		session.setAttribute("listSms", listSms);
		
		
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	} 
}