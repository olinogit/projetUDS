package twinkeuMetier;

import java.io.IOException;
import java.util.Date;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import twinkeuDAO.MessageDAO;
import twinkeuDAO.MessageDAOLocal;
import twinkeuDAO.UserDAO;
import twinkeuDAO.UserDAOLocal;
import twinkeuJPA.Message;
import twinkeuJPA.UserId;
import twinkeuJPA.Users;

/**
 * Servlet implementation class MessageMetier
 */
public class MessageMetier extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	@EJB
	MessageDAOLocal md;
	
	@EJB
	UserDAOLocal ud;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MessageMetier() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String objet = request.getParameter("objet");
		String sms = request.getParameter("sms");
				
		HttpSession session = request.getSession();
						
		Users user  = (Users) session.getAttribute("userSession");	
		
		
		//int tel = Integer.parseInt(desti);
		//Users destinataire = ud.searchByTel(tel);
		
		Date d = new Date();
		
		Message message = new Message(sms, d, user, objet);
		
		md.addMessage(message);
		
		this.getServletContext().getRequestDispatcher("/editsms.jsp" )
		.forward( request, response );
	}

}
