package twinkeuDAO;

import java.util.List;

import javax.ejb.Local;

import twinkeuJPA.Message;
import twinkeuJPA.Users;


@Local
public interface MessageDAOLocal {
	
	public Message addMessage(Message sms);
	public void deleteMessage(long code);
	public Message searchMessage(long mid);
	public Message mergeMessage(Message sms);
	public List<Message> allSms();
	public List<Message> smsByUser(Users edit);

}
