package twinkeuDAO;

import java.util.List;

import javax.ejb.Remote;

import twinkeuJPA.Message;
import twinkeuJPA.Users;

@Remote
public interface MessageDAORemote {
	public Message addMessage(Message sms);
	public void deleteMessage(long code);
	public Message searchMessage(long mid);
	public Message mergeMessage(Message sms);
	public List<Message> allSms();
	public List<Message> smsByUser(Users edit);

}
