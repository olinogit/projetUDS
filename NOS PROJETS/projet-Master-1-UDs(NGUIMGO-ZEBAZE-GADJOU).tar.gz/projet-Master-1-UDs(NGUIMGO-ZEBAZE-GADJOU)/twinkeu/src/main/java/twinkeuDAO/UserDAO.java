package twinkeuDAO;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import twinkeuJPA.UserId;
import twinkeuJPA.Users;

@Stateless
//@LocalBean
public class UserDAO  implements UserDAOLocal, UserDAORemote{
	
	@PersistenceContext(unitName="picod")
	EntityManager em ;
	
	public UserDAO() {
		super();
	}

	public Users addUser(Users user){
		em.persist(user);
		return user;
		
	}
	
	public void deleteUser(UserId uid){
		Users user = new Users();
		user = em.find(Users.class, uid);
		em.remove(user);
	}
	
	public Users searchUser(UserId uid){
		Users user = new Users();
		user = em.find(Users.class, uid);
		
		return user;
		
	}
	
	public Users mergeUser(Users user){
		String login = user.getLogin();
		String passwd = user.getPasswd();
		UserId id = new UserId(login, passwd);
		Users oldUser = em.find(Users.class, id);
		em.merge(user);
		return oldUser;
	}
	
	public Users searchByTel(long tel){
		String requete=("select user from Users user where user.numTel_user="+tel+"");
		Query query = em.createQuery(requete);
		Users user = (Users) query.getSingleResult();
		return user;
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<Users> searchByname(String nom){
		String requete=("select user from Users user where user.nom_user='"+nom+"'");
		Query query = em.createQuery(requete);		
		ArrayList<Users> listuser = (ArrayList<Users>)query.getResultList();
		return listuser;
	}
	
	public Users searchBypasswd(String pass){
		String requete=("select user from Users user where user.passwd='"+pass+"'");
		Query query = em.createQuery(requete);
		Users user = (Users) query.getSingleResult();
		return user;
	}
	
	@SuppressWarnings("unchecked")
	public List<Users> getAllUsers(){
		String requete = "select user from Users user";
		Query query = em.createQuery(requete);		
		List<Users> listuser;
		
		listuser = query.getResultList();
		return listuser;
	}
	
		
	public Users connecterUsers( UserId uid ){
						
		Users user = searchUser(uid);
				
		return user;
		
	}
	

}
