package twinkeuDAO;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import twinkeuJPA.UserId;

public class ConnexionForm {

	private static final String CHAMP_login  = "login";
	private static final String CHAMP_PASS   = "passwd";
	private Map<String, String> erreurs      = new HashMap<String, String>();
	
	private String resultat;
	
	public Map<String, String> getErreurs() {
		return erreurs;
	}
		
	public String getResultat() {
		return resultat;
	}

	public void setResultat(String resultat) {
		this.resultat = resultat;
	}



	public UserId getLogin( HttpServletRequest request ) throws NullPointerException{
		/* Récupération des champs du formulaire */
		String login = getValeurChamp( request, CHAMP_login );
		String passwd = getValeurChamp( request, CHAMP_PASS );
		UserId uid = new UserId();
		/* Validation du champ login. */
		try {
			validationlogin( login );
		} catch ( Exception e ) {
			setErreur( CHAMP_login, e.getMessage() );
		}
		
		/* Validation du champ mot de passe. */
		try {
			validationpasswd( passwd );
		} catch ( Exception e ) {
			setErreur( CHAMP_PASS, e.getMessage() );
		}
		//user.setPasswd( passwd );
		
		uid = new UserId(login, passwd);
				
		return uid;
		
	}
	/**
	 * Valide le login saisie.
	 */
	private void validationlogin( String login ) throws Exception {
		if(login.length()>10){
			throw new Exception("Merci d'entrer un login d'au plus 10 caracteres");
		}
	}
	/**
	 * Valide le mot de passe saisi.
	 */
	private void validationpasswd( String passwd ) throws Exception {
		if ( passwd != null ) {
			if ( passwd.length() < 3 ) {
				throw new Exception( "Le mot de passe doit contenir au moins 3 caractères." );
			}
		} else {
			throw new Exception( "Merci de saisir votre mot de passe." );
		}
	}
	/*
	 * Ajoute un message correspondant au champ spécifié à la map des erreurs.
	 */
	private void setErreur( String champ, String message ) {
		erreurs.put( champ, message );
	}
	/*
	 * Méthode utilitaire qui retourne null si un champ est vide, et son contenu
	 * sinon.
	 */
	private static String getValeurChamp( HttpServletRequest request, String nomChamp ) {
		String valeur = request.getParameter( nomChamp );
		if ( valeur == null || valeur.trim().length() == 0 ) {
			return null;
		} else {
			return valeur;
		}
	}

}
