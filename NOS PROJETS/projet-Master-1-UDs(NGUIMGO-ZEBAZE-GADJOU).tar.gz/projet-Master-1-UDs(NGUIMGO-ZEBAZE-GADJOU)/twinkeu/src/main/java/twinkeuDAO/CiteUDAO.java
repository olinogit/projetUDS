package twinkeuDAO;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import twinkeuJPA.CiteU;

@Stateless
@LocalBean
public class CiteUDAO {
	
	@PersistenceContext(unitName="picod")
	EntityManager em ;
	
	public CiteUDAO() {
		super();
	}

	public CiteU addCiteU(CiteU cite){
		em.persist(cite);
		return cite;
		
	}
	
	public void deleteCiteU(int cid){
		CiteU cite = em.find(CiteU.class, cid);
		em.remove(cite);
	}
	
	public CiteU searchCiteU(String nom){
		CiteU cite = em.find(CiteU.class, nom);
		return cite;
	}
	
	public CiteU mergeCiteU(CiteU cite){
		long cid = cite.getIdcu();		
		CiteU oldCiteU = em.find(CiteU.class, cid);
		em.merge(cite);
		return oldCiteU;
	}
	
	public CiteU searchCiteByName(String nom){
		String requete=("select cite from CiteU cite where cite.nomcu='"+nom+"'");
		Query query = em.createQuery(requete);
		CiteU cite = (CiteU) query.getSingleResult();
		return cite;
	}
}
