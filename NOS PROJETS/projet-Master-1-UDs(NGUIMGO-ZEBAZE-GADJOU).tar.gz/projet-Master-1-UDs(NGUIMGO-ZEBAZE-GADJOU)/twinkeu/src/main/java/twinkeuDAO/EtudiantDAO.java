package twinkeuDAO;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import twinkeuJPA.UserId;
import twinkeuJPA.Etudiant;

@Stateless
@LocalBean
public class EtudiantDAO {
	
	@PersistenceContext(unitName="picod")
	EntityManager em ;
	
	public EtudiantDAO() {
		super();
	}

	public Etudiant addEtudiant(Etudiant etud){
		em.persist(etud);
		return etud;
		
	}
	
	public void deleteEtudiant(UserId eid){
		Etudiant etud = em.find(Etudiant.class, eid);
		em.remove(etud);
	}
	
	public Etudiant searchEtudiant(UserId eid){
		Etudiant etud = em.find(Etudiant.class, eid);
		return etud;
	}
	
	public Etudiant mergeEtudiant(Etudiant etud){
		String login = etud.getLogin();
		String passwd = etud.getPasswd();
		UserId eid = new UserId(login, passwd);
		Etudiant oldetud = em.find(Etudiant.class, eid);
		em.merge(etud);
		return oldetud;
	}
	
	public Etudiant searchByname(String nom){
		String requete=("select etud from Etudiant etud where etud.nom_user='"+nom+"'");
		Query query = em.createQuery(requete);
		Etudiant etud = (Etudiant) query.getSingleResult();
		return etud;
	}

}
