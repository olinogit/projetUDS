package twinkeuDAO;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;

import twinkeuJPA.UserId;
import twinkeuJPA.Users;

@Local
public interface UserDAOLocal {

	public Users addUser(Users user);

	public void deleteUser(UserId uid);

	public Users searchUser(UserId uid);

	public Users mergeUser(Users user);

	public Users searchByTel(long tel);

	public ArrayList<Users> searchByname(String nom);

	public Users searchBypasswd(String pass);
	
	public List<Users> getAllUsers();

	public Users connecterUsers(UserId uid);

}
