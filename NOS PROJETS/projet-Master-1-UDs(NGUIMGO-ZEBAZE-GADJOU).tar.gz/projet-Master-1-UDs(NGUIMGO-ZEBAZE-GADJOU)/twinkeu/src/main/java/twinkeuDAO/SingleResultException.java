package twinkeuDAO;

public class SingleResultException extends Exception {

	private static final long serialVersionUID = 1L;

	public SingleResultException() {
		super("Le resultat de cette requette n'est pas unique");
	}

	public SingleResultException(String arg0) {
		super(arg0);
		
	}

	public SingleResultException(Throwable arg0) {
		super(arg0);
		
	}

	public SingleResultException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
