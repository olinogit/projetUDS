package twinkeuDAO;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import twinkeuJPA.Message;
import twinkeuJPA.Users;

@Stateless
public class MessageDAO implements MessageDAOLocal, MessageDAORemote{

	@PersistenceContext(unitName="picod")
	EntityManager em ;
	
	public MessageDAO() {
		super();
	}

	public Message addMessage(Message sms){
		em.persist(sms);
		return sms;
		
	}
	
	public void deleteMessage(long code){
		Message sms = em.find(Message.class, code);
		em.remove(sms);
	}
	
	public Message searchMessage(long mid){
		Message sms = em.find(Message.class, mid);
		return sms;
	}
	
	public Message mergeMessage(Message sms){
		long mid = sms.getCodeMessage();
		Message oldsms = em.find(Message.class, mid);
		em.merge(sms);
		return oldsms;
	}

	@SuppressWarnings("unchecked")
	public List<Message> allSms() {
		String requete = "select sms from Message sms";
		List<Message> listSms;
		Query query = em.createQuery(requete);			
		
		listSms = query.getResultList();
		return listSms;
		
	}

	@SuppressWarnings("unchecked")
	public List<Message> smsByUser(Users edit) {
		String requete = "select sms from Message sms where sms.editeur=:edit";
		
		List<Message> listSms;
		Query query = em.createQuery(requete);			
		query.setParameter("edit", edit);
		
		listSms = query.getResultList();
		return listSms;
	}
	
	

}
