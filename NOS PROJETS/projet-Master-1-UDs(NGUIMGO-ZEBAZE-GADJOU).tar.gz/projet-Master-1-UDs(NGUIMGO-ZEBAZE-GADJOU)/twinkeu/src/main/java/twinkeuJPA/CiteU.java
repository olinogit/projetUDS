package twinkeuJPA;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;


@Entity
@SequenceGenerator(name="sequence_citeu",sequenceName="citeu_seq")
public class CiteU implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sequence_citeu")
	private long idcu;
	
	private String nomcu;
	
	private String coordoGeo;
	
	@ManyToOne
	private Users concierge;
	
	public CiteU() {
		super();
		
	}
	
	

	public CiteU(String nomcu, String coordoGeo, Users concierge) {
		super();
		this.nomcu = nomcu;
		this.coordoGeo = coordoGeo;
		this.concierge = concierge;
	}



	public long getIdcu() {
		return idcu;
	}

	public void setIdcu(long idcu) {
		this.idcu = idcu;
	}

	public String getNomcu() {
		return nomcu;
	}

	public void setNomcu(String nomcu) {
		this.nomcu = nomcu;
	}

	public String getCoordoGeo() {
		return coordoGeo;
	}

	public void setCoordoGeo(String coordoGeo) {
		this.coordoGeo = coordoGeo;
	}

	public Users getConcierge() {
		return concierge;
	}

	public void setConcierge(Users concierge) {
		this.concierge = concierge;
	}

	
	
	
	
}
