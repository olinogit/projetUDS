package twinkeuJPA;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Inheritance(strategy=InheritanceType.JOINED)
@IdClass(UserId.class)
public class Users implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	private String login;
	
	@Id
	private String passwd;
	
	private String nom_user;
	
	private String prenom_user;
	
	@Temporal(TemporalType.DATE)
	@Basic(fetch=FetchType.LAZY)
	private Date datenaiss;
	
	private long numTel_user;
	
	public Users() {
		super();			
		
	}

	public Users(String login, String passwd, String nom_user,
			String prenom_user, Date datenaiss2, long numTel_user) {
		super();
		this.login = login;
		this.passwd = passwd;
		this.nom_user = nom_user;
		this.prenom_user = prenom_user;
		this.datenaiss = datenaiss2;
		this.numTel_user = numTel_user;
		
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	public String getNom_user() {
		return nom_user;
	}

	public void setNom_user(String nom_user) {
		this.nom_user = nom_user;
	}

	public String getPrenom_user() {
		return prenom_user;
	}

	public void setPrenom_user(String prenom_user) {
		this.prenom_user = prenom_user;
	}

	public Date getDatenaiss() {
		return datenaiss;
	}

	public void setDatenaiss(Date datenaiss) {
		this.datenaiss = datenaiss;
	}

	public long getNumTel_user() {
		return numTel_user;
	}

	public void setNumTel_user(long numTel_user) {
		this.numTel_user = numTel_user;
	}
	
	

}
