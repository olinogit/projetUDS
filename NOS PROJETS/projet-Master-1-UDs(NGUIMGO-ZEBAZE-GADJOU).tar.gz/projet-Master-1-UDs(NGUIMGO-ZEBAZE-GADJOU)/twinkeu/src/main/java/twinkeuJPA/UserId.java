package twinkeuJPA;

import java.io.Serializable;

public class UserId implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String login;
	
	private String passwd;

	public UserId() {
		super();
	}

	public UserId(String login, String passwd) {
		super();
		this.login = login;
		this.passwd = passwd;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	
	public boolean equals(Object obj) {
		boolean resultat = false;
		if (obj == this) {
			resultat = true;
		} else {
			if (!(obj instanceof UserId)) {
				resultat = false;
			} else {
				UserId autre = (UserId) obj;
				if (!login.equals(autre.login)) {
					resultat = false;
				} else {
					if (passwd != autre.passwd) {
						resultat = false;
					} else {
						resultat = true;
					}
				}
			}
		}
		return resultat;
	}
	
	public int hashCode() {
		return (login + passwd).hashCode();
	}
	
	

}
