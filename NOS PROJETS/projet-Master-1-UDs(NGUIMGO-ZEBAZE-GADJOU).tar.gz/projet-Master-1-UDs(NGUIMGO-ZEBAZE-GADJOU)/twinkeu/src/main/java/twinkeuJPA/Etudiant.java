package twinkeuJPA;



import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;

@Entity
public class Etudiant extends Users {
	
	private static final long serialVersionUID = 1L;

	@Basic(fetch=FetchType.LAZY)
	private String matriculeEtd;
	
	@Basic(fetch=FetchType.LAZY)
	private String filiereEtd;
	
	@Basic(fetch=FetchType.LAZY)
	private int niveauEtd;	
	
	@ManyToOne
	private CiteU citeu;

	public Etudiant() {
		super();
		
	}

	public Etudiant(String login, String passwd, String nom_user,
			String prenom_user, Date datenaiss, String matriculeEtd,
			String filiereEtd, int niveauEtd, int numTel_user, CiteU citeu) {
		super(login, passwd, nom_user, prenom_user, datenaiss, numTel_user);
		
		this.matriculeEtd = matriculeEtd;
		this.filiereEtd = filiereEtd;
		this.niveauEtd = niveauEtd;
		
		this.citeu = citeu;
	}

	public String getMatriculeEtd() {
		return matriculeEtd;
	}

	public void setMatriculeEtd(String matriculeEtd) {
		this.matriculeEtd = matriculeEtd;
	}

	public String getFiliereEtd() {
		return filiereEtd;
	}

	public void setFiliereEtd(String filiereEtd) {
		this.filiereEtd = filiereEtd;
	}

	public int getNiveauEtd() {
		return niveauEtd;
	}

	public void setNiveauEtd(int niveauEtd) {
		this.niveauEtd = niveauEtd;
	}

	public CiteU getCiteu() {
		return citeu;
	}

	public void setCiteu(CiteU citeu) {
		this.citeu = citeu;
	}
	

}
