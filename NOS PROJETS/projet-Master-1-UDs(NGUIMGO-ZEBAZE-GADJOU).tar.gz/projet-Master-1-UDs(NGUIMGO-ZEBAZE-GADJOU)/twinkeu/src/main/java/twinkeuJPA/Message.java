
package twinkeuJPA;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@SequenceGenerator(name="sequence_message",sequenceName="sms_seq")
public class Message implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="sequence_message")
	private long codeMessage;
	
	private String message;
	
	@Temporal(TemporalType.DATE)
	private Date dateEnvoie;
	
	@ManyToOne
	private Users editeur;
	
	
	private String objet;

	public Message() {
		super();
		
	}

	public Message(String message, Date dateEnvoie, Users edit, String obj) {
		super();
		this.message = message;
		this.dateEnvoie = dateEnvoie;
		this.editeur = edit;
		this.objet = obj;
	}

	public long getCodeMessage() {
		return codeMessage;
	}

	public void setCodeMessage(long codeMessage) {
		this.codeMessage = codeMessage;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getDateEnvoie() {
		return dateEnvoie;
	}

	public void setDateEnvoie(Date dateEnvoie) {
		this.dateEnvoie = dateEnvoie;
	}

	public Users getEditeur() {
		return editeur;
	}

	public void setEditeur(Users editeur) {
		this.editeur = editeur;
	}

	public String getObjet() {
		return objet;
	}

	public void setObjet(String objet) {
		this.objet = objet;
	}

	
	

}
